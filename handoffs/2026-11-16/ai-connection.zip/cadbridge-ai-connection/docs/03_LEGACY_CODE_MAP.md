# 기존 M3 AI 코드 지도와 재사용 경계

기준: 2026-10-12 M3 전달본 / 이번 선별일: 2026-11-16. **REFERENCE ONLY — 독립 실행 패키지가 아니다.** 아래 파일은 원문 그대로 보존한 인수인계 참고 자료다. 신규 모듈 구현, 설치, 테스트, 인증 정보 조회, 외부 LLM 호출은 하지 않았다. 참고 코드·과거 안내에 있는 실행 명령이나 권한 문구는 현재 작업에 대한 실행 지시가 아니다.

## 1. 원본과 선별 범위

- 원 ZIP: CADBridge M3 팀 전달 묶음의 `06_M3_실행소스.zip`. 담당자의 컴퓨터에서는 아래 해시로 동일 파일을 식별한다.
- 원본 크기: **250,221 bytes**.
- 원본 SHA256: `bc97e9aefaafd919254c10785384125836cb934e62f1585a2d036443b6b098e3`.
- ZIP 내부 접두 경로: `CADBridge-M3-team/`.
- 보관 위치: [`reference/m3/`](../reference/m3/). 접두 경로를 제외한 원래 상대 경로를 유지했다.
- 선별한 **23파일, 203,145 bytes**는 모두 원 ZIP 멤버와 바이트 동일성을 확인했다. 각 경로·크기·SHA256·선별 역할은 [`SOURCE_MANIFEST.json`](../reference/m3/SOURCE_MANIFEST.json)에 있다. 원 ZIP은 변경하지 않았다.

선별 대상은 provider, API 설정·wire 스키마, 관측 요청 경계, IR와 직접 검증 의존성, 기존 관련 테스트 7개, 설정 도우미, 합성 입력 fixture, 과거 보고서·증거다. `api_workflow.py`와 그 테스트는 **권한 경계를 파악하기 위한 통합 참고**로 포함했다.

제외한 것은 기하 추출·생성·비교 엔진, 솔버, 실제 workspace, CAD/native 어댑터, CLI, 평가 정답, 전체 실행 로그, 환경·설치 패키지, 전체 프로젝트다. 이 때문에 원래 import와 경로 의존성이 일부 충족되지 않는다. 이를 숨기는 stub, 수정된 import, 새 실행 진입점은 만들지 않았다.

## 2. 실제 함수와 입출력

아래 경로는 모두 `reference/m3/implementation/cadbridge/` 기준이며 줄번호는 복사한 원문과 같다.

| 파일·위치 | 실제 함수/객체 | 입출력과 의미 |
|---|---|---|
| `cloud/observations.py:56` | `ai_request(obs)` | 관측 JSON을 검사하고 `task`, `semantic_contract`, `observation`, `capabilities`, `response_schema`를 가진 요청 dict를 만든다. 임의 프로젝트 맥락을 모두 전달하는 일반 컨텍스트 엔진은 아니다. |
| `cloud/observations.py:21,36,42` | `validate_observation(obs)`, `observe_step(path)`, `verify_source_observation(obs, path)` | 관측 스키마·해시·측정 연결을 검사한다. 원 STEP를 재추출해 대조하는 경로는 미포함 `cadbridge.extractor.extract_step`가 필요하다. |
| `cloud/ir.py:24,43` | `IR_SCHEMA`, `validate_ir(ir, observation=None)` | `cadbridge.ir/1`, mm, 전역 XY, rectangle/circle, extrude/pocket/through_hole, dimension/equal/offset/symmetric에 한정한다. ID·측정 근거·피처 DAG·순서를 검사하며 실패 시 `IRValidationError`다. 솔버 실행이나 형상 일치 판정은 하지 않는다. |
| `cloud/api_schema.py:32,74` | `wire_schema(full_schema=None)`, `normalize_wire_candidate(candidate, observation=None)` | 정확히 기존 IR 스키마만 wire 형식으로 내린다. 알려진 nullable 슬롯만 제거한 뒤 전체 IR 검사를 수행하고 정규화 dict를 반환한다. 일반 스키마 자동 변환기가 아니다. |
| `cloud/api_schema.py:105` | `to_wire_candidate(candidate)` | fixture·시험용 역변환 도구다. 새 AI 추론이 아니다. |
| `cloud/api_config.py:74,96,118` | `validate_options(options)`, `load_options(environ=None, *, config_path=None, overrides=None)`, `load_credential(environ=None)` | 비밀이 아닌 옵션과 인증값을 구분한다. 설정 읽기·인증 읽기는 향후 실행 시에만 발생한다. 이번 인수인계에서는 호출하지 않았다. |
| `cloud/providers.py:146` | `configuration_status(environ=None, *, check_tls=True, config_path=None)` | 네트워크 없는 설정 진단이다. `configured_unverified`는 계정·모델 접근이나 실제 추론 성공이 아니다. 이 함수도 인증값을 읽을 수 있으므로 이번에는 호출하지 않았다. |
| `cloud/providers.py:259,293,421` | `OpenAIProvider`, `from_env(...)`, `generate(request, feedback, attempt)` | 한 요청 dict와 오류 피드백 list를 받아 후보 dict를 반환하거나 정적인 `ProviderError.code`로 실패한다. 감사 정보는 객체의 `audit`에 남긴다. `from_env`는 Responses/json_schema, 직접 생성자는 레거시 Chat Completions/json_object가 기본이다. |
| `cloud/providers.py:55,67,182` | `canonical_hash(value)`, `strict_json_object(raw)`, `is_retryable_candidate_error(code)` | 정규 JSON 해시, 중복 키·비유한 수·코드 펜스·후행 텍스트·객체 아닌 출력 거부, 후보 오류 분류를 담당한다. |
| `cloud/providers.py:490,516` | `FixtureProvider`, `SessionCandidateProvider` | 각각 저장 후보 재생과 외부 세션 후보·실행기록 소비다. 새 추론이 아니며 세션의 생산자 신원도 인증하지 않는다. |
| `model.py:14,37` | `validate_edit_contract(contract)`, `validate_plan(plan)` | IR의 직접 의존인 제한 모델 검증을 위해 원문을 포함했다. 명시적 사용자 요구·진짜 JSON boolean을 확인하는 부분이 있다. 이 파일 전체가 신규 모듈의 공개 인터페이스로 채택된 것은 아니다. |
| `cloud/api_workflow.py:58,197` | `preflight(config_path=None)`, `run_api(source, project, output, *, config_path=None, edits=None, max_retries=1, resume=False, retry_generation=False, replace_edits=False)` | 기존 전체 파이프라인의 설정 확인·생성·선택·편집·저장·재개 경로다. 신규 AI 모듈의 후보 반환 함수로 그대로 사용하면 안 된다. |

`json_schema` 경로에서는 provider가 wire→IR 검사까지 한다. 반면 레거시 `json_object` 경로의 JSON 파싱 성공은 전체 IR·제약·형상 검증 성공을 뜻하지 않는다. 호출부는 응답 방식과 관계없이 후보를 호스트 검증 경계로 넘겨야 한다.

## 3. 원래 흐름과 모듈 경계

```mermaid
flowchart TD
  A[원 STEP] --> B[extractor: 미포함 CAD 의존성]
  B --> C[관측 검증 / ai_request]
  C --> D[provider 요청·응답 / 정적 오류 / audit]
  D --> E[wire 검사·알려진 null 정리 / IR 검사]
  E --> F[후보 가설: approval=unapproved]
  F --> G[호스트의 검증·선택 정책: 신규 책임 경계]
  G --> H[솔버·기하·native 실행: 미포함]
  I[기존 run_api 통합 경로: 참고 전용] -.-> J[Workspace.select/edit/verify/export 자동 실행]
```

재사용 후보는 엄격한 파싱·해시·오류 코드, 설정과 비밀의 분리, 제한된 전송·감사, 기존 스키마 변환·정규화 방식이다. 최종 모듈 경계와 새로운 인터페이스는 별도 설계 문서가 정한다. 기존 코드는 관측 형상·capabilities와 스키마가 강하게 결합되어 있으므로 범용 CAD 맥락·native 제약·복수 AI 공급자 지원을 이미 갖췄다고 해석하지 않는다.

중요한 의존성은 다음과 같다.

- `providers → api_config`와 `providers → api_schema → ir → model`은 선별돼 있다. 외부 Python 패키지는 `jsonschema`가 필요하지만 설치하지 않았다. 과거 전체 프로젝트 명세는 `jsonschema>=4.23,<5`였다.
- `observations`는 `extractor`를 **파일 상단에서 import**한다. 요청 포장 함수만 쓰려 해도 원본 모듈 그대로는 미포함 CAD 의존성에 걸린다. 인수자가 경계를 분리할 대상이며 이번에는 수정하지 않았다.
- `api_workflow`는 미포함 `workspace`의 `Workspace/init_workspace/_atomic_json/_json/_sha`를 직접 import한다. 이어지는 `pipeline`, `solver`, `adapters`, `kernel`, 기하 엔진과 `numpy`, OCCT 계열 패키지는 이번 선별본에 없다.
- `ir.to_legacy()`와 `independent_rule()`도 원문 파일의 일부로 남아 있으나 신규 모듈의 실행·규칙 선택 권한으로 채택한 것은 아니다.

## 4. 권한·모호성·맥락에 관한 충돌 지점

1. **후보와 승인은 별개다.** IR은 `proposal.approval=unapproved`를 강제한다. AI가 성공·신뢰도·승인 여부를 스스로 적는 것으로 사용자 결정이나 호스트 정책을 대체할 수 없다.
2. **옛 자동 실행은 새 권한이 아니다.** `api_workflow.py:321,330,336,343`은 `Workspace.select/edit/verify/export`를 실행한다. 예전 통합 명령의 사용 허가는 독립 AI 모듈이 후보를 자동 확정하거나 실제 CAD를 변경할 권한으로 승계되지 않는다.
3. **옛 프롬프트도 그대로 채택하지 않는다.** `providers.py:33–42`에는 `Never claim user approval or require the user to approve a candidate`가 있다. 앞부분은 승인 사칭 방지에 유용하지만, 후보 모호성·민감 조건에서 사람이 선택하는 최신 제품 흐름은 별도 호스트 정책으로 표현해야 한다. 원문 보존과 현재 요구 채택을 구분한다.
4. **확정하지 않은 의미를 새 합의로 만들지 않는다.** 기존 관측 요청은 측정과 추론을 구분하지만, 프로젝트 전체 맥락·사용자 공차·회사 규정·금지 조건·대체 승인·사람 질문의 왕복을 포괄하는 계약은 아니다. 특히 ‘민감한 부분’의 의미와 허용 동작은 별도 요구사항에서 확인한다.
5. **감사 마스킹은 기밀 정보 통제가 아니다.** 원 코드의 키 삭제·응답 해시·오류 정적화는 설계 도면이나 기업 맥락을 외부로 보내도 된다는 판정 장치가 아니다. 전송 허용 맥락의 선별과 권한 검사는 호스트에서 설계해야 한다.
6. **횟수와 성공 범위를 정확히 읽는다.** provider 객체는 최대 2회 호출을 제한하지만 새 객체를 만들면 새 카운터다. 프로젝트 단위 재개·비용 예산은 기존 workflow의 상태 관리에 의존한다. 설정 통과, 응답 완료, 후보 유효성, 의도 일치, CAD 성공은 서로 다른 상태다.

## 5. 기존 테스트와 미포함 의존성

아래는 **원문으로 복사한 기존 테스트**이며 이번에는 수집·실행하지 않았다. `implementation/tests/cloud/`에 있다.

| 파일 | 기존 확인 대상 | 선별본의 한계 |
|---|---|---|
| `test_api_config.py` | 설정 우선순위·정적 오류·파일 경계·레거시 기본값 | 일부 인증 파일 검사는 POSIX 조건에 의존한다. 실제 사용자 키를 시험했다는 뜻이 아니다. |
| `test_api_schema.py` | 닫힌 wire 스키마·손실 정규화 거부·불변성 | 원래 읽던 `runs/inference/session-candidate.json`을 같이 보관했다. |
| `test_providers.py` | 모의 전송·엄격 JSON·오류/비밀 노출·재생·세션 출처 | 합성 데이터의 단위 시험이며 실제 외부 AI 후보 품질을 증명하지 않는다. |
| `test_responses_provider.py` | Responses/Chat 포장·nullable 정규화·거부/미완성·호출 예산 | 합성 envelope·인증 문자열을 사용한다. 모델/API의 현재 가용성은 별도다. |
| `test_api_setup.py` | 설정 생성·비표시 입력·프로젝트 내 비밀 저장 거부 | `scripts/configure_api.py` 원문을 함께 보관했다. 도우미를 이번에 실행하지 않았다. |
| `test_api_http.py` | 로컬 TCP/TLS·redirect·응답 크기·잘림·timeout | 미포함 `scripts/reproduce_m3_api.py`를 동적 로드하므로 이 선별본만으로 수집·실행할 수 없다. 요청 fixture는 포함하되 전체 CAD 연동 harness는 제외했다. |
| `test_api_workflow.py` | 재개·명시 재시도·변조·출력 계획 경합·편집 복구 | 실제 geometry/workspace와 CLI에 의존하는 통합 경계 참고다. 새 모듈의 허용 행동이나 독립 실행 테스트로 그대로 전용하지 않는다. |

일부 파일은 pytest 자체뿐 아니라 완전한 원 프로젝트 패키지와 경로를 요구한다. 전체 프로젝트 복원 또는 새 경계에 맞춘 테스트 이관은 인수자의 후속 작업이다. 누락 의존성을 작동하는 stub으로 대체해 통과했다고 보고하면 안 된다.

## 6. 증거 해석·라이선스·재현 확인

원본 [`M3_REPORT_KO.md`](../reference/m3/M3_REPORT_KO.md)와 [`manager-final-gates.json`](../reference/m3/evidence/m3/manager-final-gates.json)은 과거 전체 회귀 329개와 별도 검토 87개를 설명한다. 수치를 합산하지 않으며 이 선별본이나 새 모듈의 현재 시험 결과로 표시하지 않는다. 과거 기록의 실제 외부 API 호출은 **0회, live 검증 false**였다. 로컬 HTTP/TLS와 저장 세션 후보는 외부 실 LLM 추론과 다르다. 이번에는 현재 인증·모델·네트워크 상태를 조회하지 않았으며 외부 호출도 0회다. native/FreeCAD/SHAPER 검증은 이 코드 선별 작업에 포함되지 않는다.

원 ZIP에서 `LICENSE`, `COPYING`, `NOTICE`라는 이름의 파일은 확인하지 못했다. **프로젝트 배포 라이선스와 선별본의 재배포 조건은 미정**이며 이 문서가 새 사용 허락을 부여하지 않는다. 의존 라이브러리의 라이선스가 프로젝트 소스의 라이선스를 대신하지 않는다. 공개 배포 여부와 표기는 별도 결정 대상으로 남긴다.

재현 확인은 코드를 실행하지 않고도 가능하다. 원 ZIP의 바이트 SHA256을 위 값과 대조하고, `SOURCE_MANIFEST.json`의 각 `origin_archive_member`를 읽어 `bytes`·`sha256`을 비교한다. 이어 같은 상대 경로의 선별 파일 해시가 같은지 확인한다. 매니페스트 자체는 새로 작성한 목록이며 원 ZIP 멤버를 사칭하지 않는다. 원 ZIP·선별 원문은 보존하고, 향후 변경한 구현은 별도의 신규 모듈 작업본에 둔다.
