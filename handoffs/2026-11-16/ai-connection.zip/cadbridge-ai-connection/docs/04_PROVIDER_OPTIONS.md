# LLM 공급자·인증·비용 선택 근거

조사일: **2026-11-16 KST**  
상태: **공식 자료 조사와 인수인계용 제안. 계정 설정·키 생성·모델 설치·실제 API 호출은 하지 않음.**

이 문서는 **확인 사실 / 기술 추천 / 미확인 계정·환경 / 담당자 결정**을 구분한다. 공식 문서에 모델이 있다는 사실과 해당 사용자 계정에서 호출할 수 있다는 사실은 다르다. 사용자가 채택한 첫 CAD 쌍은 **FreeCAD 1.1.4 + SALOME SHAPER 9.16.0**이다. CAD 조합 채택은 LLM 공급자·모델·요금제 확정을 뜻하지 않는다.

## 1. 현재 확인된 준비 상태

**확인 사실 — 로컬 확인 범위:** 주 담당자가 현재 Windows의 프로세스·사용자 환경에서 아래 이름의 존재 여부만 점검했고 모두 `False`였다. 값이나 비밀 설정 파일은 읽거나 출력하지 않았다.

`OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `GEMINI_API_KEY`, `GOOGLE_API_KEY`, `OPENROUTER_API_KEY`, `OLLAMA_HOST`

`Get-Command`에서는 `ollama`, `docker`, `gh`를 PATH에서 찾지 못했고 `git`은 확인했다. 이것은 프로그램 미설치의 증거가 아니다.

**미확인 계정·환경:** `OPENAI_API_KEY_FILE`, 다른 비밀 보관소·파일·기계 환경, ChatGPT 요금제, API 조직·잔액·권한, RAM·VRAM, 로컬 모델·서버 상태는 이 점검으로 확인되지 않았다. 새 클라우드 작업의 환경도 별도 확인 대상이다. 따라서 “키나 LLM이 어디에도 없다” 또는 “실호출 준비가 완료됐다”고 단정하지 않는다.

## 2. 가장 적게 변경하는 기본 경로

**기술 추천:** 기존 M3의 **OpenAI Responses API + Structured Outputs(`json_schema`)** 경로를 우선 재사용하고, 첫 비교 기준 모델로 `gpt-6.1-sol`을 제안한다. 제한 CAD 표현·제약·의존 순서 생성의 품질을 먼저 측정한 뒤 비용이 더 낮은 모델과 비교한다. 이는 CAD 성능을 검증한 추천이 아니다.

**확인 사실 — M3 보존 소스:** `06_M3_실행소스.zip` 내부 `implementation/cadbridge/cloud/`에는 `providers.py`, `api_config.py`, `api_schema.py`, `api_workflow.py`가 있다. 공식 Responses/Chat Completions 선택, 명시적 모델 설정, 구조화 응답 변환·검사, 비밀 분리, 호출 예산·재개 처리가 구현돼 있다. 당시 검증은 보존 후보를 반환하는 로컬 HTTP 시험이며 외부 API 실호출은 0회였다. 현재 라이브러리·모델과의 호환성이나 실제 후보 품질은 다시 확인해야 한다.

현재 공식 문서도 GPT-6 계열의 Responses와 구조화 출력을 설명한다. [GPT-6 사용 안내](https://developers.openai.com/api/docs/guides/latest-model), [Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs?api-mode=responses)

**담당자 결정:** 기본 모델과 비교 모델, 출력 토큰 한도·추론 강도·작업당 호출 한도, 비용 상한을 정한다. 모델·API·외부 공급자를 오류 뒤 자동으로 바꾸지 않는다. M3 기본 생성 예산은 최초 1회와 후보 교정 최대 1회다.

**호환성 확인 사항:** 공식 Sol 문서의 추론 강도는 `low/medium/high/xhigh/max`다. M3 설정 형식이 어떤 값을 받는다는 사실만으로 선택 모델도 그 값을 지원한다고 판단하지 않는다. 추론 사용 시 `temperature` 등 지원되지 않는 옵션을 보내지 않도록 현재 요청을 대조한다. [Sol 모델 계약](https://developers.openai.com/api/docs/models/gpt-6.1-sol), [현재 모델 호환성 안내](https://developers.openai.com/api/docs/guides/latest-model)

## 3. 공식 문서에서 확인한 API 모델 후보와 비용

아래는 조사일의 **Standard·짧은 입력 문맥(272K 이하)·USD/100만 토큰** 요율이다. 계정별 접근 가능성은 미확인이다. 모델 이름을 비슷한 별칭으로 바꾸거나 날짜가 붙은 snapshot ID를 만들어 쓰지 않는다.

| 역할 제안 | 실제 API 모델 ID | 입력 | 출력 | 판단 근거 |
|---|---|---:|---:|---|
| 첫 품질 기준 | `gpt-6.1-sol` | $2.00 | $10.00 | 공식 설명은 복잡한 코딩·전문 작업용. 제한 CAD 후보 생성에 우선 비교할 기술 추천 |
| 낮은 비용 비교 | `gpt-6-luna` | $0.10 | $0.50 | 공식 설명은 범위가 명확한 대량 작업용. CAD 제약 품질은 별도 측정 |
| 어려운 사례 비교 | `gpt-6-astra` | $10.00 | $50.00 | 공식 설명은 가장 까다로운 추론·코딩 작업용. 상시 사용으로 확정하지 않음 |
| 도면 입력 확장 후보 | `gpt-6.1-terra` | $1.00 | $5.00 | 시각 추론·기술 도면 해석용 설명이 있음. 현재 관측 JSON 흐름에 반드시 필요한 모델은 아님 |

모델 근거: [Sol](https://developers.openai.com/api/docs/models/gpt-6.1-sol), [Luna](https://developers.openai.com/api/docs/models/gpt-6-luna), [Astra](https://developers.openai.com/api/docs/models/gpt-6-astra), [Terra](https://developers.openai.com/api/docs/models/gpt-6.1-terra). 요율 근거: [공식 API 가격표](https://developers.openai.com/api/docs/pricing).

**계산 예시:** 입력 10,000토큰·정산 대상 출력 4,000토큰인 요청 1회는 Sol $0.06, Luna $0.003, Astra $0.30다. 예상 사용량을 가정한 산술 예시이며 청구액이나 비용 상한 보장이 아니다. 추론 토큰도 출력으로 정산될 수 있고 교정 요청·캐시 쓰기·긴 문맥·선택한 처리 속도·지역 설정은 비용을 바꾼다. [추론 토큰 및 출력 한도](https://developers.openai.com/api/docs/guides/reasoning)

## 4. API 키·구독 크레딧·ChatGPT 로그인은 서로 다른 경로

### A. API 프로젝트 인증 — M3 재사용 경로

**확인 사실:** 공식 API는 개발용 사용자 프로젝트 키 또는 앱용 service account 등의 인증을 설명한다. [API keys and service accounts](https://developers.openai.com/api/docs/guides/api-keys)

**준비 항목:** 사용할 API 조직·프로젝트·모델 권한·가용 크레딧, 승인된 실행 환경의 비밀 주입 경로. 키를 채팅·명령 인수·Git·일반 JSON에 넣지 않는다. M3는 환경 또는 프로젝트 밖 개인 파일을 사용하지만 현재 실제 자격증명 상태는 확인하지 않았다. 소스에는 비밀이 없는 설정 예시만 둔다.

**미확인 계정:** ChatGPT 앱에서 모델을 쓴다는 사실만으로 M3 프로그램에 이 인증이 준비되지는 않는다. 계정 권한·요청 옵션 호환성은 사용자가 허용한 실제 요청 전까지 미검증이다.

### B. 자격이 있는 구독자의 API 크레딧 혜택

**확인 사실:** 현재 공식 안내에는 자격을 갖춘 **Pro·Business** 구독을 소유 API 조직에 연결해 API 크레딧을 청구하는 혜택이 있다. 활성 무료 크레딧이 있으면 API 결제 수단 없이 사용할 수 있다고 안내한다. 소유자·동일 이메일·유료 구독 기간 등 자격과 만료 조건이 있다. [API credits for ChatGPT subscribers](https://developers.openai.com/api/docs/guides/chatgpt-api-credits)

이는 API 조직의 비용을 충당하는 경로이며 **API 프로젝트 인증을 대신하는 기능은 아니다**. 모든 ChatGPT 요금제에 무제한 무료 API가 포함된다는 뜻도 아니다. 사용자의 구독 종류·혜택 자격·청구·연결·잔액은 확인하지 않았다. 새 구매를 하기 전에 해당 혜택의 적용 가능성부터 담당자가 확인할 수 있다.

### C. Sign in with ChatGPT — 별도 구현이 필요한 구독 사용 경로

**확인 사실:** 공식 OSS·로컬 호스팅 앱 안내에는 OAuth 등록과 사용자 동의를 통해 자격 있는 Responses 요청에 ChatGPT 구독을 사용하는 경로가 있다. API 키 없이 가능한 경로지만 기존 앱 로그인 세션을 임의로 재사용하는 방식은 아니다. 구독 사용 권한은 로그인 권한과 별개이며 사용량은 기존 구독 한도를 소비한다. 사용자의 ChatGPT 대화·메모리에 자동 접근하지 않는다. [개발자 빠른 시작](https://developers.openai.com/siwc/quickstart), [OSS·로컬 앱 개요](https://developers.openai.com/siwc/token-sharing-open-source), [사용자 권한·사용량 설명](https://learn.chatgpt.com/docs/sign-in-with-chatgpt)

**기술 판단:** M3에는 이 OAuth 등록·토큰 수명주기·계정 선택 경로가 없다. 별도 인증 공급자 구현과 지원 모델·구조화 출력·실행 위치 제약 확인이 필요하다. 위 API 가격표를 구독 사용량 계산에 그대로 적용하지 않는다.

**담당자 결정:** CADBridge의 실제 배포가 OSS·로컬 호스팅 범위에 맞는지 확인한다. 오픈소스 CAD 두 개를 이용한다는 사실만으로 앱 자체의 자격이 성립하지 않는다. 유료·원격 호스팅 앱은 공식 안내상 별도 경로가 있으므로 같은 조건을 가정하지 않는다. 이번 인수인계에서는 등록·동의·계정 연결을 수행하지 않는다.

## 5. 로컬 대안: Ollama + 공개 가중치 모델

**확인 사실:** Ollama 로컬 API는 `format`에 JSON Schema를 전달하는 구조화 출력을 지원한다. 현재 문서는 Ollama cloud에는 구조화 출력이 지원되지 않는다고 명시하므로 로컬 경로와 혼동하지 않는다. [Ollama Structured Outputs](https://docs.ollama.com/capabilities/structured-outputs)

등록된 비교 후보로 [`qwen3:8b`](https://ollama.com/library/qwen3:8b)가 있다. 공식 모델 목록의 해당 양자화 파일은 약 5.2GB이며, 이것은 필요한 전체 RAM·VRAM 수치가 아니다. 모델 라이선스 확인과 함께 실행 메모리·문맥 길이·추론 속도를 측정해야 한다. 최신·최고 모델이라고 추천하는 것이 아니라 실제 등록이 확인된 로컬 비교 예시다.

**기술 판단:** 로컬 계산에는 외부 API 토큰 요금 대신 장비·전력·운영 부담이 있다. 현재 PC의 적합성과 CAD 후보 품질은 미검증이다. `ollama`가 PATH에서 보이지 않는 상태를 반영하되 설치 여부를 단정하지 않는다. 모델 설치·다운로드·서버 실행은 하지 않았다.

**담당자 결정:** 로컬 우선 여부와 장비 예산을 정한다. 선택하면 별도 로컬 공급자 어댑터와 명시적 endpoint 허용 범위를 설계한다. M3가 공식 OpenAI endpoint를 고정한 경계를 임의 주소 치환으로 우회하지 않는다. 로컬 실패 시 외부 API로 자동 전송하지 않는다.

## 6. 구조화 출력과 시험의 경계

**확인 사실:** Structured Outputs는 지원 스키마에 맞는 완료 응답 형식을 제한한다. 거부·미완성·API 오류 처리와 스키마가 표현하지 못하는 업무 규칙 검사는 여전히 필요하다. 필수 필드, 제한된 선택 필드의 null 표현, 추가 필드 제한 등을 점검해야 한다. [공식 형식 제약](https://developers.openai.com/api/docs/guides/structured-outputs?api-mode=responses)

**재사용할 M3 경계:** 관측·지원 기능·의미 계약만 AI 입력으로 만들고 평가 정답을 제외한다. 후보는 엄격한 JSON 파싱 → API용 스키마 확인·정규화 → 전체 IR·참조·측정 근거 검사 → 솔버 → 형상·편집·저장 검사로 전달한다. AI에게 실행 코드를 만들거나 사용자 승인을 주장하게 하지 않는다. 설명용 `rationale`은 후보 근거 요약이며 비공개 내부 추론을 요구하지 않는다.

**독립된 두 검증 흐름:**

- **LLM 없는 native 관문:** 고정된 검증용 공통 모델로 CAD 스케치·제약·피처를 생성하고 저장·종료·새 프로세스 재열기·치수 변경·재생성을 확인한다. 이 단계는 LLM 인증 없이 진행 가능하지만 AI 추론 성과로 표시하지 않는다.
- **실제 LLM 관문:** 허용된 공급자·모델의 실제 요청에서 나온 새 후보를 동일한 검사로 보낸다. 규칙 후보, 저장 후보 재생, 세션 에이전트 후보, 모의 전송, 외부 실제 요청, 로컬 실제 추론의 출처를 분리한다. 인증 오류·거부·형식 오류·솔버 모순·형상 불일치·native 저장 실패를 하나의 “AI 실패”로 뭉개지 않는다.

향후 구현에서는 공급자·모델 ID, 비밀이 없는 요청 식별 해시, 제공되는 응답 ID·사용량, 검사한 후보·근거 요약·단계별 실패를 연결해 추적한다. 이것은 새 기록 형식의 설계 요구이며 이번 조사에서 실제 응답이나 실행 로그를 생성했다는 뜻이 아니다. 전송·저장 전에 비밀을 제거하고 원시 대화 전체를 복사하지 않는다.

후보 형식 통과, 형상 일치, 편집 의도 적합, native 수명주기 통과는 별도 결과다. 모호한 설계 의도는 후보와 근거를 사용자에게 보여 선택하게 한다. CAD 기능 차이의 자동 대체 허용 범위는 사용자 권한 설정으로 별도 정의할 사항이다.

## 7. 전담자가 사용자에게 확인할 결정

1. **인증·비용 경로:** 기존 M3 API 방식, 자격 있는 구독 크레딧 활용, 별도 Sign in with ChatGPT 구현, 로컬 실행 중 우선 경로.
2. **작업 예산:** 첫 실험의 총 비용 한도와 외부 전송을 허용할 형상·설계 정보 범위. 계정·조직·결제·키 값 자체는 이 문서나 채팅에 받지 않는다.
3. **첫 모델 비교:** 기본 후보 `gpt-6.1-sol`과 낮은 비용 후보 중 실제 시험할 조합. 모델 선택은 계정 권한 확인과 대표 부품 결과로 확정한다.

전담자는 위 결정과 비밀이 없는 사전 확인까지 구체화한 뒤, 허용된 실제 호출을 별도 단계로 진행한다. 이 문서에는 키·원시 대화·전체 실행 로그를 복제하지 않았으며 구현 코드도 추가하지 않았다.
