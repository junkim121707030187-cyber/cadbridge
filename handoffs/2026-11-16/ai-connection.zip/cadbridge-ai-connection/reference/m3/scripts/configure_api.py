#!/usr/bin/env python3
"""Create local API settings without putting a credential in shell history.

No HTTP request is made. A key is stored only with explicit --store-key and a
hidden terminal prompt. Never pass a credential as a command-line argument.
"""
from __future__ import annotations

import argparse
import getpass
import json
import os
from pathlib import Path
import re
import sys
import warnings


def exclusive_write(path: Path, content: bytes) -> None:
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(path, flags, 0o600)
    try:
        with os.fdopen(descriptor, "wb") as output:
            output.write(content)
            output.flush()
            os.fsync(output.fileno())
    except BaseException:
        path.unlink(missing_ok=True)
        raise


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, help="New non-secret JSON settings file")
    parser.add_argument("--model", required=True, help="Exact model enabled for your API account")
    parser.add_argument("--api", choices=["responses", "chat_completions"], default="responses")
    parser.add_argument("--response-format", choices=["json_schema", "json_object"], default="json_schema")
    parser.add_argument("--max-output-tokens", type=int, default=8192)
    parser.add_argument("--timeout", type=float, default=45)
    parser.add_argument("--store-key", metavar="PRIVATE_FILE", help="Optional POSIX-only hidden terminal prompt; use a private path outside the project")
    args = parser.parse_args(argv)
    created_key = None
    try:
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:/-]{0,199}", args.model):
            raise ValueError("invalid_model_configuration")
        if not 1 <= args.max_output_tokens <= 16384 or not 0 < args.timeout <= 60:
            raise ValueError("invalid_request_bounds")
        config = Path(args.out)
        if config.exists() or config.is_symlink():
            raise ValueError("configuration_already_exists")
        if not config.parent.is_dir():
            raise ValueError("configuration_parent_required")
        if args.store_key:
            if os.name != "posix":
                raise ValueError("use_environment_or_os_secret_manager_on_this_platform")
            if not sys.stdin.isatty():
                raise ValueError("hidden_interactive_terminal_required")
            key_path = Path(args.store_key)
            project_root = Path(__file__).resolve().parents[1]
            if key_path.resolve().is_relative_to(project_root):
                raise ValueError("credential_file_must_be_outside_project")
            if key_path.exists() or key_path.is_symlink():
                raise ValueError("credential_file_already_exists")
            if not key_path.parent.is_dir():
                raise ValueError("credential_parent_required")
            if key_path.absolute() == config.absolute():
                raise ValueError("distinct_configuration_and_credential_paths_required")
            with warnings.catch_warnings():
                warnings.simplefilter("error", getpass.GetPassWarning)
                secret = getpass.getpass("API key (hidden; not sent yet): ")
            if not secret or len(secret) > 8191 or not re.fullmatch(r"[!-~]+", secret):
                raise ValueError("invalid_authentication_configuration")
            exclusive_write(key_path, secret.encode("ascii") + b"\n")
            created_key = key_path
            del secret
        settings = {"model": args.model, "api": args.api,
                    "response_format": args.response_format,
                    "max_output_tokens": args.max_output_tokens, "timeout": args.timeout}
        exclusive_write(config, (json.dumps(settings, indent=2) + "\n").encode("utf-8"))
        print(json.dumps({"status": "PASS", "configuration_created": True,
                          "credential_file_created": created_key is not None,
                          "next": "Set OPENAI_API_KEY_FILE or OPENAI_API_KEY, then run api preflight --config with this settings file.",
                          "network_attempted": False, "live_api_validated": False}))
        return 0
    except (OSError, ValueError, EOFError, KeyboardInterrupt, getpass.GetPassWarning) as exc:
        if created_key is not None:
            try:
                created_key.unlink(missing_ok=True)
            except OSError:
                pass
        code = str(exc) if type(exc) is ValueError else "configuration_setup_failed"
        print(json.dumps({"status": "FAIL", "error": code, "network_attempted": False}))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
