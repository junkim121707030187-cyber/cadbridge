"""All envelopes/credentials are synthetic; these are not live API evidence."""
from copy import deepcopy
import json
from pathlib import Path
import urllib.error
import pytest
from cadbridge.cloud import providers as p
from cadbridge.cloud.api_schema import to_wire_candidate, wire_schema
from cadbridge.cloud.ir import IR_SCHEMA

ROOT=Path(__file__).resolve().parents[3]
KEY='sk-m3-synthetic-never-live-12345'

@pytest.fixture
def candidate():
    return json.loads((ROOT/'runs/inference/session-candidate.json').read_text())


def envelope(candidate=None, **changes):
    value={'id':'resp_synthetic','model':'configured-model','status':'completed','error':None,
           'incomplete_details':None,
           'usage':{'input_tokens':100,'output_tokens':200,'total_tokens':300,
                    'output_tokens_details':{'reasoning_tokens':50}},
           'output':[{'type':'reasoning','summary':[]},
                     {'type':'message','id':'msg_synthetic','role':'assistant','status':'completed',
                      'content':[{'type':'output_text','text':json.dumps(candidate or {'hello':'world'})}]}]}
    value.update(changes)
    return json.dumps(value).encode()


def test_responses_strict_wire_payload_and_normalized_candidate(candidate):
    captured=[]
    def transport(request,*args):
        captured.append(request)
        return envelope(to_wire_candidate(candidate))
    provider=p.OpenAIProvider('configured-model',KEY,api='responses',response_format='json_schema',
                              reasoning_effort='high',max_output_tokens=4096,transport=transport)
    request={'response_schema':deepcopy(IR_SCHEMA),'task':'Propose CAD IR from observations'}
    result=provider.generate(request,[],0)
    assert result==candidate
    assert captured[0].full_url==p.RESPONSES_ENDPOINT
    payload=json.loads(captured[0].data)
    assert payload['text']['format']=={'type':'json_schema','name':'cadbridge_ir_wire_v1','strict':True,'schema':wire_schema()}
    assert payload['reasoning']=={'effort':'high'} and payload['max_output_tokens']==4096
    assert payload['store'] is False and payload['stream'] is False
    assert 'tools' not in payload and 'response_format' not in payload and 'max_completion_tokens' not in payload
    user=json.loads(payload['input'][0]['content'])['request']
    assert user['response_schema']==wire_schema() and 'null' in user['wire_contract']
    entry=provider.audit[0]
    assert entry['mode']=='mock_transport' and entry['network_attempted'] is False
    assert entry['transport_invoked'] is True and entry['external_api_attempted'] is False
    assert entry['provider_response_received'] is True and entry['inference_completed'] is True
    assert entry['usage']['total_tokens']==300 and entry['api_response_id']=='resp_synthetic'
    assert entry['timeout_scope']=='socket_inactivity'
    assert entry['candidate_sha256']==p.canonical_hash(candidate)
    assert entry['wire_schema_sha256']==p.canonical_hash(wire_schema())
    assert 'provider_response' not in entry and KEY not in json.dumps(entry)


def test_chat_strict_format_is_wrapped_correctly(candidate):
    captured=[]
    def transport(request,*args):
        captured.append(json.loads(request.data))
        return json.dumps({'choices':[{'finish_reason':'stop','message':{'role':'assistant','content':json.dumps(to_wire_candidate(candidate))}}]}).encode()
    provider=p.OpenAIProvider('model',KEY,response_format='json_schema',transport=transport)
    assert provider.generate({'response_schema':IR_SCHEMA},[],0)==candidate
    fmt=captured[0]['response_format']
    assert fmt['type']=='json_schema' and fmt['json_schema']['strict'] is True
    assert 'schema' not in fmt and fmt['json_schema']['schema']==wire_schema()


@pytest.mark.parametrize('change,code',[
    ({'status':'incomplete','incomplete_details':{'reason':'max_output_tokens'}},'incomplete_completion'),
    ({'status':'failed','error':{'message':KEY}},'provider_response_error'),
    ({'status':'completed','incomplete_details':{'reason':'max_output_tokens'}},'incomplete_completion'),
    ({'output':[]},'invalid_response_envelope'),
    ({'output':[{'type':'function_call','arguments':'{}'}]},'unexpected_tool_call'),
    ({'output':[{'type':'message','status':'completed','role':'assistant','content':[{'type':'refusal','refusal':KEY}]}]},'provider_refusal'),
    ({'output':[{'type':'message','status':'incomplete','role':'assistant','content':[]}]},'invalid_response_message'),
    ({'output':[{'type':'reasoning','summary':[]}]},'ambiguous_response_output'),
])
def test_responses_incomplete_refusal_tool_ambiguous_rejection(change,code):
    provider=p.OpenAIProvider('model',KEY,api='responses',transport=lambda *args:envelope(**change))
    with pytest.raises(p.ProviderError,match='^'+code+'$'):provider.generate({},[],0)
    assert KEY not in json.dumps(provider.audit)
    assert p.is_retryable_candidate_error(code) is False


@pytest.mark.parametrize('status,code',[(400,'invalid_api_request'),(401,'authentication_rejected'),
    (403,'permission_denied'),(404,'model_or_endpoint_not_found'),(422,'invalid_api_request'),
    (429,'rate_limit_or_quota'),(500,'provider_unavailable'),(503,'provider_unavailable'),(418,'http_error')])
def test_http_classification_is_terminal_and_no_internal_retry(status,code):
    called=[]
    def transport(*args):
        called.append(True)
        raise urllib.error.HTTPError(p.RESPONSES_ENDPOINT,status,KEY,{},None)
    provider=p.OpenAIProvider('model',KEY,api='responses',transport=transport)
    with pytest.raises(p.ProviderError,match='^'+code+'$'):provider.generate({},[],0)
    assert len(called)==1 and p.is_retryable_candidate_error(code) is False
    assert provider.audit[0]['http_status']==status and KEY not in json.dumps(provider.audit)


def test_provider_budget_does_not_exceed_two_calls():
    calls=[]
    provider=p.OpenAIProvider('model',KEY,api='responses',transport=lambda *a:calls.append(True) or envelope())
    provider.generate({},[],0);provider.generate({},[],1)
    with pytest.raises(p.ProviderError,match='api_call_budget_exhausted'):provider.generate({},[],1)
    assert len(calls)==2 and provider.audit[-1]['transport_invoked'] is False


def test_falsey_transport_cannot_silently_invoke_real_default(monkeypatch):
    class Falsey:
        def __bool__(self):return False
        def __call__(self,*args):return envelope()
    monkeypatch.setattr(p,'_http_transport',lambda *a:pytest.fail('default transport called'))
    provider=p.OpenAIProvider('model',KEY,api='responses',transport=Falsey())
    assert provider.generate({},[],0)=={'hello':'world'}
    assert provider.mode=='mock_transport'


@pytest.mark.parametrize('key',[KEY,'secret"quote\\slash12345'])
@pytest.mark.parametrize('where',['value','key'])
def test_escaped_credentials_rejected_and_unrecoverable_in_audit(key,where):
    candidate={key:'echo'} if where=='key' else {'echo':key}
    raw=envelope(candidate)
    # Encode every character of the secret in the candidate JSON string as unicode escapes.
    if key==KEY:
        escaped=''.join('\\u%04x'%ord(char) for char in key)
        parsed=json.loads(raw)
        parsed['output'][1]['content'][0]['text']=parsed['output'][1]['content'][0]['text'].replace(key,escaped)
        raw=json.dumps(parsed).encode()
    provider=p.OpenAIProvider('model',key,api='responses',transport=lambda *a:raw)
    with pytest.raises(p.ProviderError,match='credential_in_output'):provider.generate({},[],0)
    log=json.dumps(provider.audit)
    assert key not in log and key not in json.dumps(json.loads(log))
    assert 'provider_response' not in provider.audit[0]
    assert provider.audit[0]['status']=='error'


def test_malformed_content_has_completion_evidence_but_no_raw_text():
    raw=json.loads(envelope());raw['output'][1]['content'][0]['text']='not-json '+KEY
    provider=p.OpenAIProvider('model',KEY,api='responses',transport=lambda *a:json.dumps(raw).encode())
    with pytest.raises(p.ProviderError,match='invalid_json_output'):provider.generate({},[],0)
    entry=provider.audit[0]
    assert entry['inference_completed'] is True and entry['status']=='error'
    assert entry['raw_response'] is None and KEY not in json.dumps(entry)


def test_unsupported_schema_never_falls_back_or_calls_transport():
    provider=p.OpenAIProvider('model',KEY,api='responses',response_format='json_schema',
                              transport=lambda *a:pytest.fail('transport called'))
    with pytest.raises(p.ProviderError,match='unsupported_ir_schema'):
        provider.generate({'response_schema':{'type':'object'}},[],0)
    assert provider.audit[0]['transport_invoked'] is False
