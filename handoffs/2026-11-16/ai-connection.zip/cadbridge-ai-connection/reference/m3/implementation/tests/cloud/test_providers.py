"""Transport simulations; none of these tests are live-provider evidence."""

import json
import ssl
import urllib.error

import pytest

from cadbridge.cloud import providers as p


REQUEST = {"observations": {"diameters": [6, 6]}, "schema_version": "cadbridge.ir/1"}
CANDIDATE = {"proposal": {"kind": "ai_proposal", "approval": "unapproved"}}
TEST_KEY = "sk-test-not-a-real-credential-12345"


def response(content=None, finish_reason="stop", **message_extra):
    return json.dumps({"id": "simulated-response", "model": "simulated-model",
                       "choices": [{"finish_reason": finish_reason,
                                    "message": {"content": json.dumps(CANDIDATE)
                                                if content is None else content,
                                                **message_extra}}]}).encode()


def provenance(**overrides):
    return {"producer": "test-session-agent", "model": "test-only-model",
            "execution_record": "tests/fixture-attestation.json",
            "execution_mode": "session_agent", "input_sha256": p.canonical_hash(REQUEST),
            **overrides}


def test_mock_transport_request_is_bounded_and_not_marked_live():
    captured = {}

    def transport(request, context, timeout, limit):
        captured.update(url=request.full_url, payload=json.loads(request.data),
                        authorization=request.get_header("Authorization"))
        assert context.verify_mode == ssl.CERT_REQUIRED
        assert context.check_hostname is True
        assert timeout <= 60
        assert limit == 1_048_576
        return response()

    provider = p.OpenAIProvider("configured-model", TEST_KEY, transport=transport)
    result = provider.generate(REQUEST, [{"code": "previous_dimension_error"}], 1)
    assert result == CANDIDATE
    assert captured["url"] == "https://api.openai.com/v1/chat/completions"
    payload = captured["payload"]
    assert payload["model"] == "configured-model"
    assert payload["n"] == 1 and payload["stream"] is False and payload["store"] is False
    assert payload["max_completion_tokens"] == 8192
    assert payload["response_format"] == {"type": "json_object"}
    assert "tools" not in payload
    assert "previous_dimension_error" in payload["messages"][1]["content"]
    assert captured["authorization"] == "Bearer " + TEST_KEY
    audit = provider.audit[0]
    assert audit["mode"] == "mock_transport"
    assert audit["status"] == "generated"
    assert audit["validation"] == "pending_pipeline_validation"
    assert audit["input_sha256"] == p.canonical_hash(REQUEST)
    assert audit["candidate_sha256"] == p.canonical_hash(result)
    assert TEST_KEY not in json.dumps(provider.audit)


def test_missing_auth_is_audited_without_network(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.setenv("CADBRIDGE_LLM_MODEL", "configured-model")
    called = []
    provider = p.OpenAIProvider.from_env(transport=lambda *args: called.append(args))
    with pytest.raises(p.ProviderError, match="^authentication_not_configured$"):
        provider.generate(REQUEST, [], 0)
    assert not called
    assert provider.audit[0]["status"] == "error"


def test_missing_model_does_not_silently_choose_one():
    provider = p.OpenAIProvider(api_key=TEST_KEY, transport=lambda *args: response())
    with pytest.raises(p.ProviderError, match="^model_not_configured$"):
        provider.generate(REQUEST, [], 0)


@pytest.mark.parametrize("raw", [
    "```json\n{}\n```", "{} trailing", "[]", '{"x":NaN}', '{"x":Infinity}',
    '{"x":1e999}', '{"a":1,"a":2}', '{"nested":{"x":1,"x":2}}', b"\xff",
])
def test_strict_json_rejects_ambiguous_or_non_json_output(raw):
    with pytest.raises(p.ProviderError):
        p.strict_json_object(raw)


@pytest.mark.parametrize("finish", ["length", "content_filter", "tool_calls", None])
def test_incomplete_completion_rejected(finish):
    provider = p.OpenAIProvider("model", TEST_KEY,
                                transport=lambda *args: response(finish_reason=finish))
    with pytest.raises(p.ProviderError, match="^incomplete_completion$"):
        provider.generate(REQUEST, [], 0)
    assert provider.audit[0]["status"] == "error"


@pytest.mark.parametrize("extra,code", [
    ({"refusal": "Cannot answer"}, "provider_refusal"),
    ({"tool_calls": [{"function": "anything"}]}, "unexpected_tool_call"),
])
def test_refusals_and_tools_are_not_candidates(extra, code):
    provider = p.OpenAIProvider("model", TEST_KEY,
                                transport=lambda *args: response(**extra))
    with pytest.raises(p.ProviderError, match=f"^{code}$"):
        provider.generate(REQUEST, [], 0)


def test_response_size_limit():
    provider = p.OpenAIProvider("model", TEST_KEY, max_response_bytes=1024,
                                transport=lambda *args: b" " * 1025)
    with pytest.raises(p.ProviderError, match="^response_size_limit$"):
        provider.generate(REQUEST, [], 0)
    assert provider.audit[0]["raw_response"] is None


def test_http_failure_records_status_without_secret_error_text():
    def transport(*args):
        raise urllib.error.HTTPError(p.ENDPOINT, 401, TEST_KEY, {}, None)

    provider = p.OpenAIProvider("model", TEST_KEY, transport=transport)
    with pytest.raises(p.ProviderError, match="^authentication_rejected$") as error:
        provider.generate(REQUEST, [], 0)
    assert provider.audit[0]["http_status"] == 401
    assert TEST_KEY not in json.dumps(provider.audit) + str(error.value)


def test_transport_failure_does_not_copy_sensitive_exception():
    def transport(*args):
        raise urllib.error.URLError("proxy password " + TEST_KEY)

    provider = p.OpenAIProvider("model", TEST_KEY, transport=transport)
    with pytest.raises(p.ProviderError, match="^transport_error$") as error:
        provider.generate(REQUEST, [], 0)
    assert TEST_KEY not in json.dumps(provider.audit) + str(error.value)


def test_credential_echo_is_redacted_and_rejected():
    provider = p.OpenAIProvider("model", TEST_KEY,
                                transport=lambda *args: response(json.dumps({"text": TEST_KEY})))
    with pytest.raises(p.ProviderError, match="^credential_in_output$"):
        provider.generate(REQUEST, [], 0)
    assert TEST_KEY not in json.dumps(provider.audit)
    assert "[REDACTED]" in json.dumps(provider.audit)


def test_ca_configuration_is_honored_not_disabled(monkeypatch):
    for name in ("SSL_CERT_FILE", "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE", "PIP_CERT"):
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setenv("PIP_CERT", "/approved/proxy-ca.pem")
    seen = []
    monkeypatch.setattr(p.ssl, "create_default_context", lambda **kwargs: seen.append(kwargs))
    p._tls_context()
    assert seen == [{"cafile": "/approved/proxy-ca.pem"}]


def test_invalid_ca_fails_closed(monkeypatch):
    monkeypatch.setenv("SSL_CERT_FILE", "/nonexistent/cadbridge-test-ca.pem")
    with pytest.raises(p.ProviderError, match="^ca_configuration_error$"):
        p._tls_context()


def test_redirect_cannot_forward_authorization():
    with pytest.raises(p.ProviderError, match="^http_redirect_rejected$"):
        p._NoRedirect().redirect_request(None, None, 302, "redirect", {},
                                         "https://untrusted.invalid/")


def test_fixture_replay_is_consumed_once_and_returns_copy():
    provider = p.FixtureProvider([CANDIDATE])
    result = provider.generate(REQUEST, [], 0)
    result["proposal"]["approval"] = "changed"
    assert CANDIDATE["proposal"]["approval"] == "unapproved"
    assert provider.audit[0]["mode"] == "fixture_replay"
    assert provider.audit[0]["status"] == "replayed"
    with pytest.raises(p.ProviderError, match="^fixture_exhausted$"):
        provider.generate(REQUEST, [], 1)


def test_session_artifact_has_honest_attestation_and_input_binding():
    provider = p.SessionCandidateProvider(CANDIDATE, provenance())
    assert provider.generate(REQUEST, [], 0) == CANDIDATE
    entry = provider.audit[0]
    assert entry["mode"] == "session_agent"
    assert entry["status"] == "consumed_session_artifact"
    assert entry["identity_verification"] == "external_attestation_not_authenticated"
    assert entry["prompt_kind"] == "reconstructed_adapter_request_not_original_session_prompt"
    assert entry["execution"] == "artifact_validation"
    assert entry["fresh_inference_in_this_process"] is False
    assert entry["origin"] == "externally_attested_session_agent"
    with pytest.raises(p.ProviderError, match="^session_candidate_exhausted$"):
        provider.generate(REQUEST, [], 1)


def test_session_input_mismatch_is_not_accepted():
    provider = p.SessionCandidateProvider(CANDIDATE, provenance())
    with pytest.raises(p.ProviderError, match="^session_input_hash_mismatch$"):
        provider.generate({"different": "observations"}, [], 0)
    assert provider.audit[0]["status"] == "error"


def test_session_candidate_hash_mismatch():
    with pytest.raises(p.ProviderError, match="^session_candidate_hash_mismatch$"):
        p.SessionCandidateProvider(CANDIDATE, provenance(candidate_sha256="0" * 64))


@pytest.mark.parametrize("change", [
    {"execution_mode": "live_provider"}, {"model": ""}, {"input_sha256": "not-a-hash"},
])
def test_session_provenance_cannot_impersonate_live_provider(change):
    with pytest.raises(p.ProviderError, match="^invalid_session_provenance$"):
        p.SessionCandidateProvider(CANDIDATE, provenance(**change))


@pytest.mark.parametrize("kwargs", [{"timeout": 61}, {"timeout": float("nan")},
                                   {"max_completion_tokens": 999999},
                                   {"max_response_bytes": 999999999}])
def test_provider_request_bounds(kwargs):
    with pytest.raises(p.ProviderError):
        p.OpenAIProvider("model", TEST_KEY, **kwargs)


@pytest.mark.parametrize('key', [42, True, ['secret'], {'api_key': TEST_KEY},
                               'key with space', 'key\tvalue', 'key\nvalue', '비밀키'])
def test_malformed_auth_is_rejected_without_transport_or_exception_leak(key):
    called = []
    provider = p.OpenAIProvider('model', key, transport=lambda *args: called.append(args))
    with pytest.raises(p.ProviderError, match='^invalid_authentication_configuration$'):
        provider.generate(REQUEST, [], 0)
    assert not called
    assert provider.audit[-1]['error_code'] == 'invalid_authentication_configuration'
    assert TEST_KEY not in json.dumps(provider.audit)


@pytest.mark.parametrize('model', [42, ['model'], 'model\nsecret', ' model ', 'x' * 201])
def test_invalid_model_configuration_is_static_error(model):
    called = []
    provider = p.OpenAIProvider(model, TEST_KEY, transport=lambda *args: called.append(args))
    with pytest.raises(p.ProviderError, match='^invalid_model_configuration$'):
        provider.generate(REQUEST, [], 0)
    assert not called


def test_provider_diagnostic_is_no_network_and_does_not_echo_values(monkeypatch):
    monkeypatch.setattr(p, '_http_transport', lambda *args: pytest.fail('network attempted'))
    result = p.configuration_status({'OPENAI_API_KEY': TEST_KEY,
                                     'CADBRIDGE_LLM_MODEL': 'private-model-id'}, check_tls=False)
    assert result['status'] == 'configured_unverified'
    assert result['live_api_validated'] is False and result['network_attempted'] is False
    assert TEST_KEY not in json.dumps(result) and 'private-model-id' not in json.dumps(result)
    assert p.configuration_status({}, check_tls=False)['errors'] == [
        'authentication_not_configured', 'model_not_configured']


def test_configuration_diagnostic_catches_invalid_trust(monkeypatch):
    monkeypatch.setenv('SSL_CERT_FILE', '/does-not-exist-cadbridge.pem')
    result = p.configuration_status({'OPENAI_API_KEY': TEST_KEY, 'CADBRIDGE_LLM_MODEL': 'model'})
    assert result['status'] == 'blocked'
    assert result['errors'] == ['ca_configuration_error']


def test_response_key_cannot_leak_api_key_in_audit():
    provider = p.OpenAIProvider('model', TEST_KEY,
                               transport=lambda *args: response(json.dumps({TEST_KEY: 'echo'})))
    with pytest.raises(p.ProviderError, match='^credential_in_output$'):
        provider.generate(REQUEST, [], 0)
    assert TEST_KEY not in json.dumps(provider.audit)
    assert TEST_KEY not in json.dumps(p._redact({TEST_KEY: 'echo'}, TEST_KEY))


def test_nonassistant_completion_role_rejected():
    provider = p.OpenAIProvider('model', TEST_KEY,
                               transport=lambda *args: response(role='tool'))
    with pytest.raises(p.ProviderError, match='^invalid_completion_role$'):
        provider.generate(REQUEST, [], 0)
