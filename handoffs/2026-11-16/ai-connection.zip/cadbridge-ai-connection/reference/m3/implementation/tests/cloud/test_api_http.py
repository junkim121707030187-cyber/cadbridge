"""Real TCP/urllib boundary checks using dummy credentials and local fixtures."""
import importlib.util
import json
from pathlib import Path
import socket
import ssl

import pytest

from cadbridge.cloud import providers

ROOT=Path(__file__).resolve().parents[3]
spec=importlib.util.spec_from_file_location('m3_http_harness',ROOT/'scripts/reproduce_m3_api.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)


@pytest.fixture(autouse=True)
def no_external_requests(monkeypatch):
    for name in ('HTTP_PROXY','http_proxy','HTTPS_PROXY','https_proxy','ALL_PROXY','all_proxy'):
        monkeypatch.delenv(name,raising=False)
    monkeypatch.setenv('NO_PROXY','127.0.0.1,localhost')
    monkeypatch.setenv('no_proxy','127.0.0.1,localhost')
    original=socket.create_connection
    def local(address,*args,**kwargs):
        assert address[0] in ('127.0.0.1','localhost','::1'),'External request forbidden in fixture test'
        return original(address,*args,**kwargs)
    monkeypatch.setattr(socket,'create_connection',local)


def provider(monkeypatch,server,api='responses',**kwargs):
    chat=server.url+'/v1/chat/completions';responses=server.url+'/v1/responses'
    monkeypatch.setattr(providers,'ENDPOINT',chat)
    monkeypatch.setattr(providers,'RESPONSES_ENDPOINT',responses)
    monkeypatch.setattr(providers,'ENDPOINTS',{'chat_completions':chat,'responses':responses})
    result=providers.OpenAIProvider(model=h.DUMMY_MODEL,api_key=h.DUMMY_KEY,api=api,
                                   transport=providers._http_transport,**kwargs)
    assert result.mode=='mock_transport'
    return result


def request():
    return json.loads((ROOT/'evaluation/m2/inference/specimen_a.request.json').read_text())


def safe_audit(p):
    assert p.audit and p.audit[-1]['mode']=='mock_transport'
    assert p.audit[-1]['network_attempted'] is True
    assert p.audit[-1]['external_api_attempted'] is False
    assert h.DUMMY_KEY not in json.dumps(p.audit)


@pytest.mark.parametrize('api',['responses','chat_completions'])
@pytest.mark.parametrize('response_format',['json_object','json_schema'])
def test_real_http_request_response_and_truthful_mode(monkeypatch,api,response_format):
    candidate=h.saved_candidate()
    with h.FixtureServer([{'json':h.envelope(candidate,api,wire=response_format=='json_schema')}]) as server:
        p=provider(monkeypatch,server,api,response_format=response_format)
        actual=p.generate(request(),[],0)
        assert actual==candidate
        assert len(server.requests)==1
        received=server.requests[0]
        assert received['method']=='POST' and received['dummy_authorization_only']
        assert received['path']==('/v1/responses' if api=='responses' else '/v1/chat/completions')
        assert received['request']['store'] is False and received['request']['stream'] is False
        safe_audit(p)


@pytest.mark.parametrize('status,code',[(401,'authentication_rejected'),(403,'permission_denied'),
                                      (429,'rate_limit_or_quota'),(500,'provider_unavailable')])
def test_real_http_error_status_no_body_or_key_leak(monkeypatch,status,code):
    marker='private-error-body-marker'
    with h.FixtureServer([{'status':status,'body':marker+' '+h.DUMMY_KEY}]) as server:
        p=provider(monkeypatch,server)
        with pytest.raises(providers.ProviderError) as exc:p.generate(request(),[],0)
        assert exc.value.code==code
        assert p.audit[-1]['http_status']==status
        assert len(server.requests)==1
        assert marker not in json.dumps(p.audit)
        safe_audit(p)


@pytest.mark.parametrize('status',[401,403,429,500])
def test_real_http_terminal_failure_does_not_spend_correction_budget(monkeypatch,tmp_path,status):
    from cadbridge.cloud.pipeline import run_pipeline
    with h.FixtureServer([{'status':status,'body':'{"error":"fixture"}'}]) as server:
        p=provider(monkeypatch,server)
        report=run_pipeline(ROOT/'evaluation/m2/inputs/specimen_a.step',request()['observation'],p,
                            tmp_path/'pipeline',max_retries=1)
        assert report['status']=='FAIL' and report['attempt_count']==1
        assert report['live_api_validated'] is False
        assert len(server.requests)==1
        assert (tmp_path/'pipeline/provider-audit.json').is_file()
        safe_audit(p)


@pytest.mark.parametrize('status',[301,302,303,307,308])
def test_real_http_redirect_never_forwards_credentials(monkeypatch,status):
    with h.FixtureServer([{'json':h.envelope(h.saved_candidate())}]) as sink:
        with h.FixtureServer([{'status':status,'headers':{'Location':sink.url+'/secret-sink'}}]) as source:
            p=provider(monkeypatch,source)
            with pytest.raises(providers.ProviderError):p.generate(request(),[],0)
            assert len(source.requests)==1 and sink.requests==[]
            safe_audit(p)


@pytest.mark.parametrize('omit_length',[False,True])
def test_real_http_response_bound(monkeypatch,omit_length):
    with h.FixtureServer([{'body':b'x'*4096,'omit_length':omit_length}]) as server:
        p=provider(monkeypatch,server,max_response_bytes=1024)
        with pytest.raises(providers.ProviderError,match='response_size_limit'):p.generate(request(),[],0)
        safe_audit(p)


@pytest.mark.parametrize('raw',[b'{',b'{"status":"completed","output":[]} trailing',b'\xff\xfe',
                              b'{"status":"completed","status":"failed"}'])
def test_real_http_malformed_json_rejected(monkeypatch,raw):
    with h.FixtureServer([{'body':raw}]) as server:
        p=provider(monkeypatch,server)
        with pytest.raises(providers.ProviderError):p.generate(request(),[],0)
        assert len(server.requests)==1;safe_audit(p)


def test_real_http_truncation_rejects_even_valid_json_prefix(monkeypatch):
    body=json.dumps(h.envelope(h.saved_candidate())).encode()
    with h.FixtureServer([{'body':body,'declared_size':len(body)+100}]) as server:
        p=provider(monkeypatch,server)
        with pytest.raises(providers.ProviderError,match='incomplete_http_body'):p.generate(request(),[],0)
        assert len(server.requests)==1;safe_audit(p)


def test_real_http_timeout_is_finite_and_not_retried(monkeypatch):
    with h.FixtureServer([{'delay':0.2,'json':h.envelope(h.saved_candidate())}]) as server:
        p=provider(monkeypatch,server,timeout=0.03)
        with pytest.raises(providers.ProviderError,match='transport_error'):p.generate(request(),[],0)
        assert len(server.requests)==1;safe_audit(p)


@pytest.fixture(scope='module')
def test_tls(tmp_path_factory):return h.create_test_tls(tmp_path_factory.mktemp('test-ca'))


def test_real_https_with_trusted_test_ca_and_hostname_verification(monkeypatch,test_tls):
    server_context,certificate=test_tls
    monkeypatch.setenv('SSL_CERT_FILE',str(certificate))
    context=providers._tls_context()
    assert context.verify_mode==ssl.CERT_REQUIRED and context.check_hostname is True
    with h.FixtureServer([{'json':h.envelope(h.saved_candidate())}],tls_context=server_context) as server:
        p=provider(monkeypatch,server)
        assert p.generate(request(),[],0)==h.saved_candidate()
        assert len(server.requests)==1;safe_audit(p)


def test_real_https_untrusted_certificate_is_rejected(monkeypatch,test_tls):
    server_context,_=test_tls
    for name in ('SSL_CERT_FILE','REQUESTS_CA_BUNDLE','CURL_CA_BUNDLE','PIP_CERT'):
        monkeypatch.delenv(name,raising=False)
    with h.FixtureServer([{'json':h.envelope(h.saved_candidate())}],tls_context=server_context) as server:
        p=provider(monkeypatch,server)
        with pytest.raises(providers.ProviderError,match='transport_error'):p.generate(request(),[],0)
        assert server.requests==[];safe_audit(p)
