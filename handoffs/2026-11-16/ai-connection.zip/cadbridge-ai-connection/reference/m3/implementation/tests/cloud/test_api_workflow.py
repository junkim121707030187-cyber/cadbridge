"""Actual CAD workflow, mocked external transport, no live-inference claim."""
from copy import deepcopy
import json
from pathlib import Path
import urllib.error

import pytest

from cadbridge import kernel
from cadbridge.geometry import build_shape
from cadbridge.cloud.api_workflow import run_api, preflight
from cadbridge.cloud.ir import independent_rule
from cadbridge.cloud.providers import OpenAIProvider
from cadbridge.cloud.workspace import Workspace, init_workspace


@pytest.fixture(scope='module')
def source(tmp_path_factory):
    path = tmp_path_factory.mktemp('api-source') / 'input.step'
    plan = {'schema_version': '0.1', 'units': 'mm',
            'base': {'id': 'base', 'cx': 0, 'cy': 0, 'z': 0, 'length': 100, 'width': 80, 'thickness': 10},
            'pockets': [], 'holes': [{'id': 'hole_1', 'cx': 20, 'cy': 0, 'diameter': 8}],
            'feature_order': ['base', 'hole_1']}
    kernel.write_step(build_shape(plan), path)
    return path


@pytest.fixture(autouse=True)
def safe_environment(monkeypatch):
    for key in ('OPENAI_API_KEY_FILE', 'CADBRIDGE_API_CONFIG'):
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv('OPENAI_API_KEY', 'mock-credential-for-offline-tests')
    monkeypatch.setenv('CADBRIDGE_LLM_MODEL', 'mock-model')


def install_mock(monkeypatch, failures=None):
    calls, providers = [], []
    failures = list(failures or [])
    def transport(request, _context, _timeout, _limit):
        payload = json.loads(request.data)
        candidate_request = json.loads(payload['messages'][1]['content'])['request']
        calls.append(deepcopy(payload))
        action = failures.pop(0) if failures else 'good'
        if isinstance(action, int):
            raise urllib.error.HTTPError('https://api.openai.com/v1/chat/completions', action,
                                         'sensitive upstream body is omitted', {}, None)
        if action == 'runtime':
            raise RuntimeError('secret runtime value mock-credential-for-offline-tests')
        candidate = independent_rule(candidate_request['observation'])
        candidate['proposal']['kind'] = 'ai_proposal'
        if action == 'invalid':
            del candidate['rationale']
        envelope = {'model': 'mock-model', 'id': 'mock-completion',
                    'choices': [{'finish_reason': 'stop', 'message': {'role': 'assistant', 'content': json.dumps(candidate)}}]}
        return json.dumps(envelope).encode()
    def from_env(cls, **kwargs):
        provider = cls(model='mock-model', api_key='mock-credential-for-offline-tests',
                       api='chat_completions', response_format='json_object', transport=transport)
        providers.append(provider)
        return provider
    monkeypatch.setattr(OpenAIProvider, 'from_env', classmethod(from_env))
    return calls, providers


def test_preflight_blocked_and_run_do_not_create_project_or_call_network(source, tmp_path, monkeypatch):
    monkeypatch.delenv('OPENAI_API_KEY', raising=False)
    monkeypatch.delenv('CADBRIDGE_LLM_MODEL', raising=False)
    calls, _ = install_mock(monkeypatch)
    report = preflight()
    assert report['status'] == 'BLOCKED' and report['api_call_count'] == 0
    result = run_api(source, tmp_path / 'project', tmp_path / 'out')
    assert result['status'] == 'BLOCKED' and not calls
    assert not (tmp_path / 'project').exists()
    assert not report['live_inference_completed'] and not report['live_api_validated']


def test_complete_workflow_resume_no_credentials_no_new_calls(source, tmp_path, monkeypatch):
    calls, _ = install_mock(monkeypatch)
    project, output = tmp_path / 'project', tmp_path / 'out'
    result = run_api(source, project, output, edits={'dim_hole_1_diameter': 10})
    assert result['status'] == 'PASS', result
    assert len(calls) == 1 and result['provider_mode'] == 'mock_transport'
    assert result['transport_call_count_this_command'] == 1
    assert result['api_call_count_this_command'] == 0
    assert result['external_api_call_count_this_command'] == 0
    assert not result['live_inference_completed'] and not result['live_api_validated']
    monkeypatch.delenv('OPENAI_API_KEY'); monkeypatch.delenv('CADBRIDGE_LLM_MODEL')
    def forbid(*args, **kwargs):
        raise AssertionError('resume must not construct a provider')
    monkeypatch.setattr(OpenAIProvider, 'from_env', forbid)
    resumed = run_api(source, project, output, resume=True)
    assert resumed['status'] == 'PASS', resumed
    assert resumed['generation_skipped'] and resumed['provider_attempt_count_this_command'] == 0
    assert resumed['transport_call_count_this_command'] == 0 and len(calls) == 1
    exported = json.loads((output / 'export.json').read_text())
    assert exported['edits'] == {'dim_hole_1_diameter': 10}
    assert run_api(source, project, tmp_path / 'other')['error']['code'] == 'project_exists_use_resume_or_retry_generation'


@pytest.mark.parametrize('http_status', [401, 403, 429, 500])
def test_terminal_http_failure_requires_explicit_generation_retry(source, tmp_path, monkeypatch, http_status):
    calls, _ = install_mock(monkeypatch, [http_status])
    project, output = tmp_path / 'project', tmp_path / 'out'
    first = run_api(source, project, output, max_retries=1)
    assert first['status'] == 'FAIL' and len(calls) == 1
    assert not output.exists()
    assert run_api(source, project, output, resume=True)['status'] == 'BLOCKED'
    assert len(calls) == 1
    retry = run_api(source, project, output, retry_generation=True)
    assert retry['status'] == 'PASS', retry
    assert len(calls) == 2
    assert run_api(source, project, tmp_path / 'again', retry_generation=True)['status'] == 'BLOCKED'
    assert len(calls) == 2


@pytest.mark.parametrize('sequence,expected,count', [(['invalid', 'good'], 'PASS', 2),
                                                   (['invalid', 'invalid'], 'FAIL', 2),
                                                   (['runtime'], 'FAIL', 1)])
def test_corrective_retry_only_and_no_sensitive_exception_leak(source, tmp_path, monkeypatch, sequence, expected, count):
    calls, _ = install_mock(monkeypatch, sequence)
    project = tmp_path / 'project'
    result = run_api(source, project, tmp_path / 'out', max_retries=1)
    assert result['status'] == expected, result
    assert len(calls) == count
    assert result['provider_attempt_count_this_command'] == count
    serialized = json.dumps(result) + ''.join(p.read_text() for p in project.rglob('*.json'))
    assert 'mock-credential-for-offline-tests' not in serialized
    if sequence[0] == 'runtime':
        assert 'secret runtime value' not in serialized


def test_unapplied_bad_edit_is_replaceable_without_api_call(source, tmp_path, monkeypatch):
    calls, _ = install_mock(monkeypatch)
    project, output = tmp_path / 'project', tmp_path / 'out'
    failed = run_api(source, project, output, edits={'dim_hole_1_diameter': -1})
    assert failed['status'] == 'FAIL' and failed['error']['code'] == 'edit_validation_failed'
    assert len(calls) == 1
    corrected = run_api(source, project, output, edits={'dim_hole_1_diameter': 10}, resume=True, replace_edits=True)
    assert corrected['status'] == 'PASS', corrected
    assert len(calls) == 1 and corrected['provider_attempt_count_this_command'] == 0


def test_checkpoint_flag_alone_cannot_claim_live_inference(source, tmp_path):
    project, output = tmp_path / 'project', tmp_path / 'out'
    init_workspace(source, project)
    import hashlib
    state = {'schema_version': 'cadbridge.api-workflow/1', 'stage': 'generation_failed',
             'requested_edits': {}, 'candidate_name': 'api-missing', 'generations': [],
             'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
             'provider_mode': 'mock_transport', 'live_api_validated': True,
             'live_inference_completed': True}
    (project / 'api-workflow.json').write_text(json.dumps(state))
    result = run_api(source, project, output, resume=True)
    assert result['status'] == 'BLOCKED'
    assert not result['live_api_validated'] and not result['live_inference_completed']


def test_export_plan_race_is_failure_without_reverting_other_edit(source, tmp_path, monkeypatch):
    calls, _ = install_mock(monkeypatch)
    original = Workspace.export
    def interleave(self, output):
        assert self.edit({'dim_base_thickness': 12})['status'] == 'PASS'
        return original(self, output)
    monkeypatch.setattr(Workspace, 'export', interleave)
    project, output = tmp_path / 'project', tmp_path / 'out'
    result = run_api(source, project, output, edits={'dim_hole_1_diameter': 10})
    assert result['status'] == 'FAIL' and result['error']['code'] == 'export_changed'
    assert len(calls) == 1
    assert Workspace(project).status()['edits']['dim_base_thickness'] == 12
    assert output.exists()  # retained evidence, never silently rolled back


def test_accepted_candidate_tamper_cannot_resume_or_generate(source, tmp_path, monkeypatch):
    calls, _ = install_mock(monkeypatch)
    project, output = tmp_path / 'project', tmp_path / 'out'
    assert run_api(source, project, output)['status'] == 'PASS'
    manifest = json.loads((project / 'workspace.json').read_text())
    candidate = next(iter(manifest['candidates'].values()))
    artifact = project / 'runs' / candidate['run'] / f"attempt-{candidate['accepted_attempt']}" / 'candidate.json'
    data = json.loads(artifact.read_text()); data['rationale'] += 'changed'; artifact.write_text(json.dumps(data))
    assert run_api(source, project, output, resume=True)['status'] == 'FAIL'
    assert len(calls) == 1


def test_invalid_output_relationship_is_rejected_before_generation(source, tmp_path, monkeypatch):
    calls, _ = install_mock(monkeypatch)
    project = tmp_path / 'project'
    result = run_api(source, project, project / 'result')
    assert result['status'] == 'FAIL' and not calls and not project.exists()


def test_cli_config_pass_through_and_preflight_is_no_network(source, tmp_path, monkeypatch, capsys):
    from cadbridge.cloud.cli import main
    config = tmp_path / 'api.json'
    config.write_text(json.dumps({'model': 'mock-model', 'api': 'chat_completions', 'response_format': 'json_object'}))
    calls, providers = install_mock(monkeypatch)
    assert main(['api', 'preflight', '--config', str(config)]) == 0
    assert json.loads(capsys.readouterr().out)['network_attempted'] is False
    assert not calls and not providers
    assert main(['api', 'run', str(source), '--project', str(tmp_path / 'project'),
                 '--out', str(tmp_path / 'out'), '--config', str(config)]) == 0
    assert len(calls) == 1
