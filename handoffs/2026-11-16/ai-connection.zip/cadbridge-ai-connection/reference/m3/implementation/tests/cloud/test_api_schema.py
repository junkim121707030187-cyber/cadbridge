from copy import deepcopy
import json
from pathlib import Path
import pytest
from jsonschema import Draft202012Validator
from cadbridge.cloud.ir import IR_SCHEMA, validate_ir
from cadbridge.cloud.api_schema import wire_schema,to_wire_candidate,normalize_wire_candidate,WireSchemaError

ROOT=Path(__file__).resolve().parents[3]

@pytest.fixture
def candidate():
    return json.loads((ROOT/'runs/inference/session-candidate.json').read_text())


def test_wire_uses_closed_objects_required_all_and_only_supported_basic_keywords(candidate):
    schema=wire_schema()
    def visit(node):
        if isinstance(node,dict):
            assert set(node)<= {'type','properties','required','additionalProperties','items','enum','anyOf'}
            if node.get('type')=='object':
                assert node['additionalProperties'] is False
                assert set(node['required'])==set(node['properties'])
                for value in node['properties'].values():visit(value)
            for key in ['items']:
                if key in node:visit(node[key])
            for item in node.get('anyOf',[]):visit(item)
    visit(schema)
    wire=to_wire_candidate(candidate)
    assert not list(Draft202012Validator(schema).iter_errors(wire))
    assert normalize_wire_candidate(wire)==candidate
    assert validate_ir(candidate)==candidate


@pytest.mark.parametrize('mutation',['unknown_schema','unknown_top','null_required','missing_nullable','bad_frame','bad_number','missing_dimension','extra_circle_dimension','bad_refs'])
def test_wire_or_full_validator_rejects_lossy_normalization(candidate,mutation):
    if mutation=='unknown_schema':
        schema=deepcopy(IR_SCHEMA);schema['properties']['unexpected']={'type':'string'}
        with pytest.raises(WireSchemaError,match='unsupported_ir_schema'):wire_schema(schema)
        return
    wire=to_wire_candidate(candidate)
    if mutation=='unknown_top':wire['unknown']=None
    elif mutation=='null_required':wire['rationale']=None
    elif mutation=='missing_nullable':wire['constraints'][0].pop('value')
    elif mutation=='bad_frame':wire['frame']['x_axis']=[0,1,0]
    elif mutation=='bad_number':wire['parameters'][0]['value']=1e10
    elif mutation=='missing_dimension':wire['constraints'][0]['value']=None
    elif mutation=='extra_circle_dimension':
        entity=next(e for s in wire['sketches'] for e in s['entities'] if e['kind']=='circle')
        entity['parameters']['length']=wire['parameters'][0]['id']
    else:wire['constraints'][0]['refs']=['not_a_parameter']
    with pytest.raises(WireSchemaError) as err:normalize_wire_candidate(wire)
    assert err.value.code in {'wire_schema_violation','candidate_ir_validation_failed'}
    assert err.value.details


def test_wire_mutation_does_not_modify_original_schema_or_candidate(candidate):
    original=deepcopy(IR_SCHEMA);original_candidate=deepcopy(candidate)
    wire=to_wire_candidate(candidate);normalize_wire_candidate(wire)
    assert IR_SCHEMA==original and candidate==original_candidate
