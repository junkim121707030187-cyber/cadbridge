"""Local setup safety; all credentials are synthetic and no network is used."""
import importlib.util
import json
import os
from pathlib import Path
import stat

import pytest

MODULE_PATH = Path(__file__).resolve().parents[3] / 'scripts/configure_api.py'
spec = importlib.util.spec_from_file_location('api_setup_helper', MODULE_PATH)
setup = importlib.util.module_from_spec(spec)
spec.loader.exec_module(setup)


def test_nonsecret_settings_are_exclusive_and_no_credential_is_requested(tmp_path, monkeypatch, capsys):
    monkeypatch.setattr(setup.getpass, 'getpass', lambda *_: pytest.fail('prompted for key'))
    config = tmp_path / 'api.json'
    args = ['--out', str(config), '--model', 'account-enabled-model']
    assert setup.main(args) == 0
    original = config.read_bytes()
    assert json.loads(original)['api'] == 'responses'
    assert setup.main(args) == 2
    assert config.read_bytes() == original
    assert 'configuration_already_exists' in capsys.readouterr().out


@pytest.mark.skipif(os.name != 'posix', reason='POSIX key-file setup contract')
def test_explicit_hidden_key_is_private_and_never_echoed(tmp_path, monkeypatch, capsys):
    secret = 'synthetic-setup-secret-12345'
    monkeypatch.setattr(setup.sys.stdin, 'isatty', lambda: True)
    monkeypatch.setattr(setup.getpass, 'getpass', lambda *_: secret)
    config, key = tmp_path / 'api.json', tmp_path / 'private.key'
    assert setup.main(['--out', str(config), '--model', 'model', '--store-key', str(key)]) == 0
    assert key.read_text() == secret + '\n'
    assert stat.S_IMODE(key.stat().st_mode) == 0o600
    assert secret not in config.read_text() + capsys.readouterr().out


def test_nontty_never_falls_back_to_echoed_input(tmp_path, monkeypatch, capsys):
    monkeypatch.setattr(setup.sys.stdin, 'isatty', lambda: False)
    monkeypatch.setattr(setup.getpass, 'getpass', lambda *_: pytest.fail('unsafe prompt'))
    config, key = tmp_path / 'api.json', tmp_path / 'private.key'
    assert setup.main(['--out', str(config), '--model', 'model', '--store-key', str(key)]) == 2
    assert not key.exists() and not config.exists()
    assert 'FAIL' in capsys.readouterr().out


@pytest.mark.skipif(os.name != 'posix', reason='POSIX key-file setup contract')
def test_config_write_failure_removes_only_just_created_key(tmp_path, monkeypatch, capsys):
    secret = 'synthetic-setup-secret-12345'
    monkeypatch.setattr(setup.sys.stdin, 'isatty', lambda: True)
    monkeypatch.setattr(setup.getpass, 'getpass', lambda *_: secret)
    config, key = tmp_path / 'api.json', tmp_path / 'private.key'
    original = setup.exclusive_write
    def injected(path, content):
        if path == config:
            raise OSError(secret)
        original(path, content)
    monkeypatch.setattr(setup, 'exclusive_write', injected)
    assert setup.main(['--out', str(config), '--model', 'model', '--store-key', str(key)]) == 2
    assert not key.exists() and not config.exists()
    assert secret not in capsys.readouterr().out


@pytest.mark.skipif(os.name != 'posix', reason='POSIX key-file setup contract')
def test_key_cannot_be_created_in_source_tree_even_with_unrecognized_suffix(tmp_path, monkeypatch, capsys):
    monkeypatch.setattr(setup.sys.stdin, 'isatty', lambda: True)
    monkeypatch.setattr(setup.getpass, 'getpass', lambda *_: pytest.fail('prompted before path guard'))
    key = MODULE_PATH.parent / 'never-create-credential.txt'
    config = tmp_path / 'api.json'
    assert setup.main(['--out', str(config), '--model', 'model', '--store-key', str(key)]) == 2
    assert not key.exists() and not config.exists()
    assert 'credential_file_must_be_outside_project' in capsys.readouterr().out
