import json
import os
from pathlib import Path
import pytest
from cadbridge.cloud.api_config import ConfigError, load_options, load_credential
from cadbridge.cloud.providers import OpenAIProvider, ProviderError, configuration_status

KEY = 'sk-local-synthetic-do-not-use-12345'


def clear_env(monkeypatch):
    for key in ['OPENAI_API_KEY','OPENAI_API_KEY_FILE','CADBRIDGE_LLM_MODEL','CADBRIDGE_API_CONFIG']:
        monkeypatch.delenv(key, raising=False)


def test_responses_default_factory_and_legacy_constructor(monkeypatch):
    clear_env(monkeypatch)
    assert OpenAIProvider.from_env().api == 'responses'
    assert OpenAIProvider.from_env().response_format == 'json_schema'
    assert OpenAIProvider().api == 'chat_completions'
    assert OpenAIProvider().response_format == 'json_object'


def test_nonsecret_config_and_model_env_precedence(tmp_path, monkeypatch):
    clear_env(monkeypatch)
    config = tmp_path/'api.json'
    config.write_text(json.dumps({'model':'config-model','api':'responses','response_format':'json_schema',
                                  'timeout':12,'max_output_tokens':512,'reasoning_effort':'high'}))
    monkeypatch.setenv('CADBRIDGE_API_CONFIG', str(config))
    monkeypatch.setenv('CADBRIDGE_LLM_MODEL','environment-model')
    monkeypatch.setenv('OPENAI_API_KEY',KEY)
    provider = OpenAIProvider.from_env()
    assert provider.model == 'environment-model' and provider.timeout == 12
    assert provider.max_output_tokens == 512 and provider.reasoning_effort == 'high'
    status = configuration_status(config_path=config, check_tls=False)
    assert status['status'] == 'configured_unverified' and not status['network_attempted']
    assert KEY not in json.dumps(status) and str(config) not in json.dumps(status)
    assert 'environment-model' not in json.dumps(status)
    assert OpenAIProvider.from_env(model='explicit-model').model == 'explicit-model'


@pytest.mark.parametrize('field,value,code', [
    ('endpoint','https://bad.invalid','unknown_api_config_field'),
    ('api_key',KEY,'unknown_api_config_field'),
    ('api',[], 'invalid_api_configuration'), ('api',{}, 'invalid_api_configuration'),
    ('response_format',[], 'invalid_response_format'),('response_format',{}, 'invalid_response_format'),
    ('api','auto', 'invalid_api_configuration'),('timeout',True,'invalid_timeout'),
    ('timeout',61,'invalid_timeout'),('max_output_tokens',0,'invalid_token_limit'),
    ('max_output_tokens',1.5,'invalid_token_limit'),('reasoning_effort','ultra','invalid_reasoning_effort'),
    ('reasoning_effort',[],'invalid_reasoning_effort'),('model','bad\nmodel','invalid_model_configuration'),
])
def test_invalid_config_static_failure_no_value_or_path(tmp_path, field, value, code):
    config=tmp_path/'sensitive-name.json'; config.write_text(json.dumps({field:value}))
    with pytest.raises(ConfigError, match='^'+code+'$') as err:
        load_options({},config_path=config)
    assert str(config) not in str(err.value) and KEY not in str(err.value)
    status=configuration_status({},config_path=config,check_tls=False)
    assert status['status']=='blocked' and code in status['errors']
    assert str(config) not in json.dumps(status)


@pytest.mark.parametrize('text',['[]','null','{"model":"a","model":"b"}','{"timeout":NaN}','{"timeout":1e999}'])
def test_bad_config_json(tmp_path,text):
    config=tmp_path/'api.json';config.write_text(text)
    with pytest.raises(ConfigError):load_options({},config_path=config)


def test_key_file_private_bounded_and_no_secret_logging(tmp_path, monkeypatch):
    clear_env(monkeypatch)
    key=tmp_path/'private-secret';key.write_text(KEY+'\n');key.chmod(0o600)
    assert load_credential({'OPENAI_API_KEY_FILE':str(key)})==KEY
    monkeypatch.setenv('OPENAI_API_KEY_FILE',str(key))
    monkeypatch.setenv('CADBRIDGE_LLM_MODEL','configured-model')
    assert OpenAIProvider.from_env()._api_key==KEY
    status=configuration_status(check_tls=False)
    assert status['status']=='configured_unverified' and status['credential_source']=='file'
    assert KEY not in json.dumps(status) and str(key) not in json.dumps(status)
    with pytest.raises(ConfigError,match='conflicting_authentication_sources'):
        load_credential({'OPENAI_API_KEY':KEY,'OPENAI_API_KEY_FILE':str(key)})


@pytest.mark.skipif(os.name!='posix',reason='POSIX permission contract')
@pytest.mark.parametrize('mode',[0o644,0o400,0o660,0o700])
def test_key_file_exact_0600_permissions(tmp_path,mode):
    key=tmp_path/'private';key.write_text(KEY);key.chmod(mode)
    with pytest.raises(ConfigError,match='credential_file_permissions'):
        load_credential({'OPENAI_API_KEY_FILE':str(key)})


def test_symlink_directory_oversize_missing_key_files_rejected(tmp_path):
    key=tmp_path/'private';key.write_text(KEY);key.chmod(0o600)
    link=tmp_path/'link';link.symlink_to(key)
    huge=tmp_path/'huge';huge.write_bytes(b'x'*8193);huge.chmod(0o600)
    for path in [link,tmp_path,huge,tmp_path/'missing']:
        with pytest.raises(ConfigError) as err:
            load_credential({'OPENAI_API_KEY_FILE':str(path)})
        assert str(path) not in str(err.value)


def test_factory_bad_file_is_static_provider_error(tmp_path,monkeypatch):
    clear_env(monkeypatch)
    monkeypatch.setenv('OPENAI_API_KEY_FILE',str(tmp_path/'not-there'))
    with pytest.raises(ProviderError,match='^credential_file_unreadable$'):
        OpenAIProvider.from_env()
