# CADBridge M3 API 통합 결과

2026-10-12 사용자 지시인 “API까지 구현하고 native 지원은 미루기”에 따라, 기존 제한 STEP 시제품의 API 연동 구현과 실행·재개 경로를 완성했다. **코드와 로컬 검증은 완료했으며, 인증키·모델이 없는 현재 환경에서는 외부 API 실호출을 검증하지 못했다.** Native 개발은 보류 상태다.

## 이번에 구현한 동작

- 공식 Responses API와 기존 Chat Completions API를 명시 설정으로 지원한다. 기본 환경 경로는 Responses와 구조화 출력이며 모델을 임의로 선택하거나 다른 API로 자동 전환하지 않는다.
- API용 스키마는 IR의 선택 항목을 명시적인 nullable 항목으로 표현한다. 반환값을 이 형식으로 검사한 뒤 허용된 null만 정규화하고 전체 IR·참조·제약·형상 검사를 다시 수행한다.
- 비밀이 아닌 JSON 설정과 키 환경/0600 개인 파일을 분리했다. 로컬 설정 도우미는 키를 비표시 터미널 입력으로 받고 프로젝트 밖에만 저장한다. 키를 채팅이나 명령 인수에 넣지 않는다.
- `api run`이 입력→후보 생성→실행·선택→선택적 편집→재검증→STEP/IR 저장을 연결한다. `--resume`은 인증 없이 검증된 후보를 사용하고 API를 재호출하지 않는다.
- 최초1회+후보 교정1회로 생성 예산을 제한한다. 인증·권한·HTTP·통신·거부·미완성 응답은 자동 재시도하지 않는다. 실패·결과 불명 뒤 새 요청은 `--retry-generation`으로 명시한다.
- 실패한 미적용 편집은 `--resume --replace-edits`로 기존 후보를 재사용해 고친다. 최종 출력은 요청한 원본·후보·치수·출처와 대조한다.

## 실제 실행 증거

| 검증 | 결과 | 증거 |
|---|---|---|
| 최종 전체 회귀 | 329 PASS, 173.68초 | evidence/m3/full-regression.log |
| 실제 loopback HTTP/TLS 경계 | 27 PASS | runs/m3-http-final/http-boundary-tests.xml |
| HTTP→CAD→편집→저장·재개 | 21 PASS, 로컬 HTTP7회 | runs/m3-http-final/http-e2e-report.json |
| API workflow 집중 회귀 | 15 PASS | runs/m3-api-workflow/unit-acceptance.json |
| 제공자/설정/스키마 집중 회귀 | 119 PASS | runs/m3-provider-check/provider-verification.json |
| 독립 Astra ultra 검토 | 87 PASS, 재현 결함6개 폐쇄 | reviews/m3/review.json |
| 검토 소스와 현재 소스 | production16파일 해시 일치 | evidence/m3/manager-final-gates.json |
| 실제 환경 무인증 실행 | BLOCKED, 통신0, 프로젝트·출력미생성, 원본불변 | runs/m3-live-preflight/unconfigured-run.json |

집중 회귀와 HTTP 경계시험은 전체329개와 겹치므로 개수를 더해 독립 시험 총수로 표시하지 않는다. 독립 검토87개는 별도 검토자가 직접 실행한 검사다.

실제 HTTP 시험 서버는 보존된 세션 AI 후보를 반환했다. 생산 urllib 전송 경로와 실제 OCCT·STEP 실행은 사용했지만 외부 OpenAI 인증·새 모델 추론은 하지 않았다. 모든 시험 출처는 mock_transport이며 live 표시가 false다. 최초 하네스는 canonical IR과 API wire 형식을 혼동해 정상 거부되었다. 실패를 runs/m3-http에 남기고 최종 성공 근거는 runs/m3-http-final로 구분했다.

## 독립 반론으로 수정한 문제

1. false로 평가되는 시험 transport가 무시되어 다른 통신 함수가 실행되던 문제를 수정했다.
2. quote/backslash 또는 Unicode escape로 표현된 합성 비밀값의 후보·감사 기록 누출을 막았다. 원문 HTTP는 hash/size로, JSON은 비밀을 제거한 구조로 저장한다.
3. 설정 도우미가 프로젝트 안에 만든 자격증명 파일이 소스 패키지에 포함될 수 있는 경로를 차단했다.
4. 손상된 checkpoint의 boolean만으로 실제 API 성공을 주장하던 오류를 수정했다.
5. 검증 직후 다른 정상 편집이 끼어들어 요청과 다른 결과가 PASS로 저장되던 문제를 수정했다. 불일치 결과는 FAIL과 조사 증거로 보존한다.
6. 잘못된 설정 타입이 약속된 정적 오류 대신 TypeError가 되던 경계를 수정했다.

같은 재현을 수정 후 다시 실행해 폐쇄했다. 별도 재개 시험은 호출 의도 저장 직후 중단, 후보가 저장된 직후 checkpoint 갱신 전 중단, 인증 없는 새 프로세스 재개, 반복 재개의 출력 불변, 명시적 재시도만 추가 호출하는 동작을 검증했다.

## 사용과 재현

자세한 실행 순서는 docs/API_QUICKSTART_KO.md다. 모델 ID는 실제 계정에서 허용된 값을 지정하며 예시 자리표시자를 그대로 API에 보내지 않는다.

```bash
python3 scripts/bootstrap.py --test
.venv/bin/python scripts/configure_api.py --model YOUR_APPROVED_MODEL_ID --out api-settings.json
.venv/bin/python -m cadbridge.cloud api preflight --config api-settings.json
.venv/bin/python -m cadbridge.cloud api run my-input.step --project runs/api-part --out runs/api-result --config api-settings.json
```

승인된 키는 비밀 환경 또는 프로젝트 밖의 개인 파일로 먼저 제공해야 한다. 현재 클라우드의 사전 검사 예상 결과는 BLOCKED다. 키를 채팅에 붙여넣도록 요구하지 않는다. 인증 없이 재현할 HTTP 시험은 다음과 같다.

```bash
.venv/bin/python scripts/reproduce_m3_api.py --out runs/new-http-reproduction
```

이는 저장된 후보를 사용하는 로컬 통신 시험이며 외부 AI 추론이 아니다. 이미 존재하는 폴더를 덮어쓰지 않는다.

## 남은 정확한 범위

이번 API 구현의 다음 검증은 승인된 인증·모델·네트워크에서 실제 후보를 생성하고 동일한 형상·편집·재개방 경로를 통과시키는 것이다. 계정 권한, 모델과 요청 옵션의 호환성, 실제 후보 품질은 아직 확인되지 않았다. 로컬 모의 응답으로 이를 성공 처리하지 않았다. 설정된 timeout은 소켓 무응답 제한이며 절대 전체 시간 상한이 아니다.

현재 형상 범위는 XY 정렬 단일 직사각 판재·분리된 상부 사각 막힌 포켓·Z 관통 홀이다. 일반 비선형 제약·자유곡면·assembly/mate 및 폭넓은 산업 표본 검증은 남아 있다. 같은 형상이 같은 원 설계 이력을 뜻하지 않는다.

Native reader/writer/설계 이력 어댑터 구현과 실제 CAD 수명주기는 사용자 지시로 보류한다. 설치·라이선스만 주어지면 이미 지원되는 상태가 아니다. 전체 CADBridge 제품이 완성되었다는 주장은 하지 않는다.

## 보존과 기준

관리6문서, 전체 소스·시험·실행 증거·리뷰는 M3 묶음에 포함한다. SOURCE_MANIFEST.json 및 scripts/verify_bundle.py로 파일별 무결성을 확인한다. M2 관리 문서는 history/M2-management에 남긴다. 공유 Page의 M3 정식 첨부가 현재 전달본이며 M0/M1/M2와 혼동하지 않는다.

공유 기준: https://chatgpt.com/space/page_694d45239e2881918932e4c52f36e159

API 계약 확인: [Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs?api-mode=responses), [Responses API reference](https://developers.openai.com/api/reference/python/resources/responses/methods/create). 제공자 계약은 모델 가용성이나 이 계정의 권한을 보증하지 않는다.
