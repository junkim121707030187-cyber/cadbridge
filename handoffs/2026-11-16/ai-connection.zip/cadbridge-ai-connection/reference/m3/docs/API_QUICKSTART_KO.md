# CADBridge API 실행 안내

이 경로는 **STEP 입력 → 외부 API 후보 → 후보 검증·선택 → 치수 편집 → 재검증 → 결과 저장**을 하나의 명령으로 연결합니다. API 인증이 없으면 네트워크를 호출하지 않고 `BLOCKED`를 반환합니다. 현재 실행 환경에는 실제 API 인증이 없으므로 실제 제공자 추론 성공과 비용·모델 가용성은 검증되지 않았습니다. HTTP 모의 서버와 주입 transport 시험은 실제 외부 AI 추론과 구분됩니다.

지원 형상은 XY 정렬 직사각 판재, 상부 사각 막힌 포켓, Z 관통 홀의 단일 솔리드입니다. 제약 솔버는 제한된 affine 관계입니다. 형상이 일치해도 유일한 원래 설계 이력이 복원되었다는 뜻은 아닙니다. **CATIA/SOLIDWORKS/NX native 구현은 이번 API 작업에서 보류**합니다.

## 1. 설치와 비밀이 아닌 설정

프로젝트 최상위에서 실행합니다. 아래 명령의 `YOUR_APPROVED_MODEL_ID`는 예시 자리표시자입니다. 실제 승인된 계정에서 사용할 모델 식별자로 바꾸세요. 도구가 모델을 임의로 선택하거나 다른 API로 자동 전환하지 않습니다.

```bash
python3 scripts/bootstrap.py --test
.venv/bin/python scripts/configure_api.py --model YOUR_APPROVED_MODEL_ID --out api-settings.json
```

직접 작성하는 설정 예시는 다음과 같습니다. API 키, 비밀 파일 경로, 임의 endpoint는 이 파일에 넣지 않습니다.

```json
{
  "model": "YOUR_APPROVED_MODEL_ID",
  "api": "responses",
  "response_format": "json_schema",
  "timeout": 45,
  "max_output_tokens": 8192
}
```

허용 키는 `model`, `api`, `response_format`, `timeout`, `max_output_tokens`, `reasoning_effort`입니다. 기본 경로는 공식 Responses API와 엄격한 JSON schema 응답입니다. 모델이 이 조합을 지원하지 않으면 오류를 보고하고 멈춥니다. 승인된 모델이 Chat Completions 조합을 필요로 할 때는 `api=chat_completions`를 명시합니다. 설정 형식·범위 검사는 제공자 설정 모듈이 수행합니다.

`--config`를 생략하면 `CADBRIDGE_API_CONFIG` 경로 또는 환경 설정을 사용합니다. 모델은 `CADBRIDGE_LLM_MODEL`로도 제공할 수 있으며, 이 환경값이 있으면 설정 파일의 `model`보다 우선합니다. API 종류·응답 형식의 자동 fallback은 없습니다. `timeout`은 소켓 비활성 제한이며 작업 전체의 절대 벽시계 제한이 아닙니다.

## 2. 비밀은 승인된 실행 환경에서만 제공

`OPENAI_API_KEY` 또는 `OPENAI_API_KEY_FILE` 중 하나를 승인된 비밀 설정으로 주입합니다. 두 값을 동시에 설정하면 모호한 인증 선택을 거부합니다. **키를 채팅, CLI 인수, 일반 JSON, Git 또는 보고서에 붙여넣지 않습니다.**

필요하면 사용자의 로컬 POSIX 터미널에서 설정 도우미를 사용할 수 있습니다. `--store-key`는 프로젝트 밖의 사용자 전용 경로와 터미널 비표시 입력을 사용합니다. 기존 파일은 덮어쓰지 않습니다. 키 경로는 생성되는 일반 config에 저장되지 않습니다. 이 기능을 실제 키가 없는 클라우드에서 자동 실행하지 않습니다.

```bash
install -d -m 700 "$HOME/.config/cadbridge"
.venv/bin/python scripts/configure_api.py --model YOUR_APPROVED_MODEL_ID --out api-settings-private.json --store-key "$HOME/.config/cadbridge/private.key"
export OPENAI_API_KEY_FILE="$HOME/.config/cadbridge/private.key"
```

`export` 명령에는 키의 **파일 경로**만 들어 있습니다. 인증 값은 provider만 읽고 감사 기록에는 비밀을 제거합니다. 기존 프록시·CA 설정은 유지하며 TLS 보호를 해제하지 않습니다.

## 3. 네트워크 없는 사전 검사

```bash
.venv/bin/python -m cadbridge.cloud api preflight --config api-settings.json
.venv/bin/python -m cadbridge.cloud doctor --config api-settings.json
```

`api preflight`는 로컬 설정·인증 존재 여부·TLS 구성만 확인합니다.

| 결과 | 의미 |
|---|---|
| `PASS`, `network_attempted=false` | 호출할 로컬 설정이 준비됨. 계정 인증 성공·모델 접근·실제 추론은 아직 미검증 |
| `BLOCKED`, 종료 코드 2 | 설정이나 비밀 준비가 부족함. `guidance`에 값 노출 없는 조치가 표시됨 |
| `live_api_validated=false` | 사전 검사에서 항상 유지됨 |

기존 `doctor`의 최상위 `status=PASS`는 진단 명령을 실행했다는 뜻입니다. 그 안의 `provider.status=blocked` 또는 `configured_unverified`를 함께 확인합니다.

## 4. API부터 결과 저장까지 실행

프로젝트 폴더와 출력 폴더는 새 경로이며 서로 포함되지 않는 별도 폴더로 지정합니다. 승인된 인증과 실제 호출을 원하는 사용자의 명령이 준비되면 다음처럼 실행합니다.

```bash
.venv/bin/python -m cadbridge.cloud api run my-input.step --project runs/api-part --out runs/api-result --config api-settings.json --max-retries 1
```

미리 알고 있는 구동 제약 ID에 대한 편집 파일이 있으면 `--edits edit.json`을 추가합니다. 예를 들어 실행 가능한 후보가 `dim_hole_1_diameter`를 실제로 정의할 때만 다음 편집이 유효합니다.

```json
{"dim_hole_1_diameter": 10}
```

AI가 다른 제약 ID를 만들 수 있으므로 처음부터 편집 ID를 알 수 없는 경우는 편집 없이 실행한 뒤 `workspace status --project runs/api-part`의 `driving_dimensions`를 확인하고 `workspace edit`를 사용합니다. `dimension`은 파라미터 값이고 `offset`은 `refs[0] - refs[1]`의 부호 있는 거리입니다.

후보는 스키마·실제 솔버·원 형상·STEP 재개방 검사를 통과한 뒤 선택됩니다. `api run` 실행에 포함된 자동 선택은 이 워크플로 실행을 요청한 것으로 처리하며, 설계 의도의 정답 승인으로 기록하지 않습니다.

API 예산은 **생성 시도당 최대 2회**입니다. 기본 `--max-retries 1`은 최초 요청 1회와 잘못된 후보에 대한 교정 1회입니다. `--max-retries 0`은 최초 요청만 실행합니다. 인증·권한·HTTP 오류, 네트워크 오류, 제공자 거부, 미완성 응답에는 자동 재시도를 하지 않습니다. 특히 429나 5xx 응답을 숨겨 반복 호출하지 않습니다. 교정 피드백에는 후보 검사 오류만 넣고 평가 정답을 넣지 않습니다.

## 5. 재시작과 중복 API 호출 방지

생성 호출 전에 `api-workflow.json`에 호출 의도를 원자 저장합니다. 이미 존재하는 프로젝트에 같은 초기 명령을 다시 실행하면 새 API 호출을 하지 않습니다.

**검증된 후보가 있으면** 다음 명령으로 재개합니다. 같은 출력 폴더가 이미 완성되어 있으면 파일 해시와 후보·편집·원 입력을 대조합니다. `--resume`은 API 제공자를 만들거나 호출하지 않으므로 인증이 제거된 환경에서도 가능합니다.

```bash
.venv/bin/python -m cadbridge.cloud api run my-input.step --project runs/api-part --out runs/api-result --resume
```

원 파일을 옮겼다면 프로젝트의 보존 복사본을 입력으로 사용합니다.

```bash
.venv/bin/python -m cadbridge.cloud api run runs/api-part/source/input.step --project runs/api-part --out runs/api-result --resume
```

검증된 후보가 없는 생성 실패 또는 결과 불명 상태에서는 `--resume`이 `BLOCKED`이며 호출 수는 0입니다. 제공자 측에서 첫 호출을 처리했지만 로컬 저장 전에 프로세스가 중단되었을 가능성을 숨기지 않습니다. 새 요청을 원할 때만 다음 명령으로 명시합니다. 이 명령은 새 호출 비용이 발생할 수 있는 **새로운 최대 2회 예산**입니다.

```bash
.venv/bin/python -m cadbridge.cloud api run my-input.step --project runs/api-part --out runs/api-result --config api-settings.json --retry-generation --max-retries 1
```

이미 검증된 후보가 있으면 `--retry-generation`을 거부하고 `--resume`을 안내합니다. 실패한 과거 후보와 증거는 보존합니다.

**후보는 통과했지만 편집이 실패했다면**, 올바른 제약 ID·값으로 편집 파일을 고친 뒤 다음처럼 재개합니다. 기존 후보에 아직 편집이 적용되지 않은 경우만 지원하며 새로운 API 호출은 없습니다.

```bash
.venv/bin/python -m cadbridge.cloud api run my-input.step --project runs/api-part --out runs/api-result --resume --replace-edits --edits corrected-edit.json
```

이미 적용된 편집을 계속 바꾸려면 일반 `workspace edit/verify/export`를 사용합니다. `--replace-edits`가 다른 명령의 편집이나 후보 선택을 몰래 되돌리지 않습니다.

```bash
.venv/bin/python -m cadbridge.cloud workspace status --project runs/api-part
.venv/bin/python -m cadbridge.cloud workspace edit --project runs/api-part --edits next-edit.json
.venv/bin/python -m cadbridge.cloud workspace verify --project runs/api-part
.venv/bin/python -m cadbridge.cloud workspace export --project runs/api-part --out runs/next-result
```

극초기 중단으로 프로젝트는 만들어졌지만 `api-workflow.json`이 없다면 API 자동 재개를 거부합니다. 프로젝트의 `workspace status`와 실행 폴더를 확인하세요. 후보가 있다면 일반 `workspace select/edit/verify/export`로 API 없이 이어갈 수 있습니다. 후보가 없고 API 실행 기록도 없는 프로젝트라면 보존된 입력을 사용해 **별도의 새 프로젝트 경로**에서 명시적으로 실행합니다. 기존 폴더를 삭제하거나 덮어써서 중단 증거를 지우지 않습니다.

## 6. 결과와 실패를 구분해서 읽기

| 필드 | 의미 |
|---|---|
| `provider_mode=live_provider` | 공식 외부 제공자 경로. 시험 transport는 `mock_transport` |
| `live_inference_completed` | 실제 live 응답 완료의 증거. 후보나 워크플로 성공과 별개 |
| `live_api_validated` | live 경로에서 검증된 후보가 존재함. 시험 mock에서는 항상 false |
| `workflow_validation=PASS` | 후보 선택·요청 편집·재검증·최종 출력의 계획 일치까지 성공 |
| `api_call_count_this_command` | 실제 네트워크 transport 호출 시도 수. 로컬 HTTP 시험은 mock 표시와 함께 해석 |
| `external_api_call_count_this_command` | 실제 외부 제공자 호출 시도 수. mock transport에서는 0 |
| `provider_attempt_count_this_command` | 네트워크 이전 실패까지 포함하는 제공자 메서드 시도 수 |
| `transport_call_count_this_command` | 주입 시험 transport도 포함하는 transport 호출 수 |
| `generation_skipped=true` | 검증된 기존 후보로 재개하여 생성 단계를 생략함 |
| `edit_task_verification=UNVERIFIED` | 사용자 설계 의도에 대한 외부 정답까지 판정하지 않음 |

`PASS`는 모든 CAD에 대한 지원이나 원래 이력의 유일한 복원을 뜻하지 않습니다. 유한 표면 비교는 연속 Hausdorff 거리의 수학적 보증이 아닙니다.

`api-workflow.json`은 작업 단계와 계획, `workspace.json`은 후보·활성 편집 상태, `runs/<ID>/provider-audit.json`과 `pipeline.json`은 생성 시도와 검사 증거입니다. 출력에는 `result.step`, 원 입력, IR, 누적 편집, 솔버·형상·타깃 보고서와 `export.json`이 저장됩니다. 프로젝트 폴더 전체를 보존해야 후보와 편집을 이어갈 수 있습니다.

API 워크플로 도중 별도 `workspace` 명령으로 후보·치수를 바꾸면 최종 출력이 API 계획과 달라질 수 있습니다. 이 경우 API 워크플로는 `FAIL`로 처리하고 다른 명령의 상태를 되돌리지 않습니다. 이미 생성된 불일치 출력은 조사 증거로 보존하며 API 계획을 충족한 결과로 취급하지 않습니다. 기존 출력이 변조되었거나 계획과 다르면 새 출력 폴더를 지정하거나 프로젝트 상태를 직접 확인하세요.

해시는 로컬 변경 탐지 수단이며 서명된 신원 인증이 아닙니다. 과거 후보를 fixture로 재생하거나 시험 서버가 후보를 반환한 결과를 새 AI 추론으로 보고하지 않습니다.
